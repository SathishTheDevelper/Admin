const express = require('express')
const app = express()
const banners = require('../models/banner')
app.get('/', function (req, res) {
    banners.find({ status: true }, function (err, images) {
        if (err) {
            res.send({
                Success: false,
                message: err.message,
            })
        }
        else {
            res.send(images)
        }
    })
}).get('/:id', function (req, res) {
    banners.findOne({ _id: req.params.id }, function (err, user_data) {
        if (err) {
            res.send({
                Success: false,
                message: err.message,
            })
        }
        else {
            res.send(user_data)
        }
    })
})
module.exports = app