const express = require('express')
const app = express();
const batch = require('../models/batch')
app.get('/', function (req, res) {
  var query = {};
  if (req.query.Course_id) query.course_id = req.query.Course_id;
  batch.find(query, function (err, data) {
    if (err) {
      res.send({
        success: false,
        message: err.message
      })
    }
    else {
      res.send(data)
    }
  });
}).get('/:id', function (req, res) {
  batch.findOne({ _id: req.params.id }, function (err, data) {
    if (err) {
      res.send({
        success: false,
        message: err.message
      })
    }
    else {
      res.send(data)
    }
  })
})
module.exports = app
