const express = require('express')
const app = express()
const model = require('../models/course')
function getChild(parent, course) {
  let data = course.filter(e => {
    return String(e.parent) == String(parent)
  });
  let result = data.map(e => {
    let obj = {};
    Object.assign(obj, e._doc);
    obj.children = getChild(e._id, course);
    return obj;
  })
  return result;
}
app.get('/', async function (req, res) {
  var course = await model.find({ status: true });
  res.send(getChild('', course));
});
module.exports = app
