const express = require('express')
const app = express()
const Course = require('../models/course')
app.get('/', function (req, res) {
  var query = {};
  if (req.query.parent) query.parent = req.query.parent;
  if (req.query.status) query.status = req.query.status;
  Course.find(query, function (err, data) {
    if (err) {
      res.send({ success: false, message: err.message })
    }
    else {
      res.send(data)
    }
  });
}).get(('/:id'), function (req, res) {
  Course.findOne({ _id: req.params.id }, function (err, data) {
    if (err) {
      res.send({
        success: false,
        message: err.message
      })
    }
    else {
      res.send(data)
    }
  })
})
module.exports = app
