const express = require('express')
const app = express.Router()
const jwt = require('jsonwebtoken');
const secret = require('../token');
/*
app.use(function (req, res, next) {
  const User = require("../models/student");
  if (req.path != '/login') {
    var token = req.headers['authorization'];
    if (token) {
      var decoded = jwt.decode(token, secret);
      User.findById(decoded.id, function (err, user) {
        if (err) {
          return res.status(401).json({ message: err.message });
        }
        else if (!user) {
          return res.status(403).send({ success: false, msg: 'Authentication failed. User not found.' });
        }
        else if (user.status == false) {

          return res.status(401).json({ message: "Not found" })
        }
        else {
          next();
        }
      })
    }
    else {
      res.send({ message: "Token is Not Provided" })
    }
  }
  else {
    next();
  }
}); */
app.use('/banner', require('./banner'))
app.use('/user', require('./user'))
app.use('/batch', require('./batch'))
app.use('/course', require('./course'))
app.use('/registered-course', require('./registered-course'))
app.use('/course-tree', require('./course-tree'))
app.use('/login', require('./login'))
module.exports = app
