
const express = require('express')
const app = express()
const registered_course = require('../models/registered-course')
app.get('/', function (req, res) {
  var query = {};
  if (req.query.student_id) query.student_id = req.query.student_id;
  registered_course.find(query, function (err, data) {
    if (err) {
      res.send({ success: false, message: err.message })
    }
    else {
      res.send(data)
    }
  });
})
app.get('/:id', function (req, res) {
  registered_course.findOne({ _id: req.params.id }, function (err, user_data) {
    if (err) {
      res.send({
        success: false,
        message: err.message
      })
    }
    else {
      res.send(user_data)
    }
  })
})
module.exports = app
