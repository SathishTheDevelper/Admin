const { Router } = require('express')
const express = require('express')
const app = express()
const Users = require('../models/user')
app.get('/', function (req, res) {
    Users.find({ status: true }, function (err, user_data) {
        if (err) {
            res.send({
                success: false,
                message: err.message
            })
        }
        else {
            res.send(user_data)
        }
    })
}).get('/:id', function (req, res) {

    Users.findOne({ _id: req.params.id }, function (err, user_data) {
        if (err) {
            res.send({
                success: false,
                message: err.message
            })
        }
        else {
            res.send(user_data)
        }
    })
})
module.exports = app