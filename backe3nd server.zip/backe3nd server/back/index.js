const express=require('express')
var cors = require('cors')
const mongoose=require('mongoose');
const app=express()
//connection 

mongoose.connect('mongodb://localhost:27017/lms2021',{
    useNewUrlParser:true,
    useUnifiedTopology:true,
    useCreateIndex: true,
    useFindAndModify: false
});

var db=mongoose.connection;
db.on('error',()=>console.log("Error in connecting to database"));
db.once('open',()=>console.log("Connected to database"));

 
app.use(cors())
app.use(express.json())
app.use(express.urlencoded({extended:true}))
console.log(__dirname);
app.use('/img',express.static(__dirname +'/img'))
app.use('/image',express.static(__dirname +'/image'))
app.use('/banner',express.static(__dirname +'/banner'))
app.use('/document',express.static(__dirname +'/document'))
app.use('/thumbnail',express.static(__dirname +'/thumbnail'))
app.use('/master',require('./master'))
app.use('/api',require('./api'))

app.get('/',(req,res)=>{
    res.send("Welome LMS");
});
app.listen(8000)
console.log("listensing")

