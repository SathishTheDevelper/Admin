const express = require('express')
const multer = require('multer')
const app = express()
const Banners = require('../models/banner')
const storage = multer.diskStorage({
    destination: (req,file,cb)=>{
	cb(null,__dirname+'/../img');
    },
    filename: function (req, file, callback) {
        callback(null, file.originalname);
    }
});
var upload = multer({
    storage: storage,
    fileFilter: function (req, file, cb) {
        if (file.mimetype == "image/png" || file.mimetype == "image/jpg" || file.mimetype == "image/jpeg") {
            cb(null, true);
        } else {
            req.fileValidationError = "Forbidden extension";
            return cb(null, false, req.fileValidationError);

        }
    }
});
app.get('/', function (req, res) {
    Banners.find(function (err, images) {
        if (err) {
            res.send({
                Sucess: false,
                message: err.message,

            })
        }
        else {
            res.send(images)
        }
    })
}).get('/:id', function (req, res) {
Banners.findOne({ _id: req.params.id }, function (err, user_data) {
        if (err) {
            res.send({
                Sucess: false,
                message: err.message,

            })
        }
        else {
            res.send(user_data)
        }
    })
}).post('/', upload.single('path'), (req, res, next) => {
    if (req.fileValidationError) {
        res.send({ 
            sucess: false, 
            message: "Error: Only .png, .jpg and .jpeg format allowed!" })
    }
    else {
        const user = new Banners({
            path: 'img/' + req.file.filename,
            caption: req.body.caption,
            status: req.body.status
        });
        user.save(function (err) {
            if (err) {
                res.send({
                    success: false,
                    message: err.message
                })
            }
            res.send({
                success: true,
                message: "Image uploaded Successfully"
            })
        })
    }
}).delete("/:id", (req, res) => {
    let _id = req.params.id
    Banners.findByIdAndDelete(_id, function (err) {
        if (err) {
            res.send({
                success: false,
                message: err.message
            })
        }
        else {
            res.send({ 
                success: true,
                message: "Image deleted successfully" })
        }
    })
})
module.exports = app
