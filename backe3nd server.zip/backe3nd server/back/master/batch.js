const express = require('express')
const app = express();
const batch = require('../models/batch')
app.get('/', (req, res) => {
  batch.find(function (err, data) {
    if (err) {
      res.send({
        success: false,
        message: err.message
      })
    }
    else {
      res.send(data)
    }
  })
}).get('/:id', function (req, res) {
batch.findOne({ _id: req.params.id }, function (err, data) {
    if (err) {
      res.send({
        success: false,
        message: err.message
      })
    }
    else {
      res.send(data)
    }
  })
}).post('/', (req, res) => {
  const user = new batch({
    course_id: req.body.course_id,
    title: req.body.title,
    description: req.body.description,
    mode: req.body.mode,
    start_time: req.body.start_time,
    end_time: req.body.end_time,
    fees_amount: req.body.fees_amount,
    min_students: req.body.min_students,
    max_students: req.body.max_students,
    staff: req.body.staff,
    alternative_staff: req.body.alternative_staff,
    status: req.body.status
});
  user.save(function (err) {
    if (err) {
      res.send({
        success: false,
        message: err.message
      })
    } else {
      res.send({
        success: true,
        message: "Created Successfully"
      })
    }
  });
}).put('/:id', function (req, res) {
  let id = req.params.id
  var User_data = {
    course_id: req.body.course_id,
    title: req.body.title,
    description: req.body.description,
    mode: req.body.mode,
    start_time: req.body.start_time,
    end_time: req.body.end_time,
    fees_amount: req.body.fees_amount,
    min_students: req.body.min_students,
    max_students: req.body.max_students,
    staff: req.body.staff,
    alternative_staff: req.body.alternative_staff,
    status: req.body.status
  }
  batch.findByIdAndUpdate(id, User_data, function (error) {
    if (error) {
      res.send({
        success: false,
        message: error.message
      })
    } else {
      res.send({
        success: true,
        message: "Updated successfully"
      })
    }
  })
}).delete("/:id", (req, res) => {
  let _id = req.params.id
  batch.findByIdAndDelete(_id, function (err) {
    if (err) {
      res.send({
        success: false,
        message: err.message
      })
    }
    else {
      res.send({
        success: true,
        message: "Deleted Successfully"
      })
    }
  })
})
module.exports = app
