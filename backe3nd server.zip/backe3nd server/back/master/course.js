const express = require('express')
const app = express()
const multer = require('multer')
const path = require('path')
const course = require('../models/course')
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    if (file.fieldname === "thumbnail") {
      cb(null, 'thumbnail')
    }
    else if (file.fieldname === "banner") {
      cb(null, 'banner')
    }
    else if (file.fieldname === "document") {
      cb(null, 'document')
    }
  },
  filename: (req, file, cb) => {
    if (file.fieldname === "thumbnail") {
      cb(null, file.fieldname + - +Date.now() + path.extname(file.originalname))
    }
    else if (file.fieldname === "banner") {
      cb(null, file.fieldname + - + Date.now() + path.extname(file.originalname))
    }
    else if (file.fieldname === "document") {
      cb(null, file.fieldname + - + Date.now() + path.extname(file.originalname))
    }
  }
})
const upload = multer({
  storage: storage,
  fileFilter: (req, file, cb) => {
    if (file.fieldname === "thumbnail" || file.fieldname === "banner") {
      if (
        file.mimetype == "image/png" || file.mimetype == "image/jpg" || file.mimetype == "image/jpeg" || file.mimetype == "video/mp4"
      ) {
        cb(null, true)
      }
      else {
        req.fileValidationError = "Forbidden extension";
        return cb(null, false, req.fileValidationError);
      }
    }
    else if (file.fieldname === "document") {
      if (
        file.mimetype == "application/pdf" || file.mimetype == "application/vnd.openxmlformats-officedocument.wordprocessingml.document"

      ) {
        cb(null, true);
      } else {
        req.fileValidationError = "Forbidden extension";
        return cb(null, false, req.fileValidationError);
      }
    }
  }
})
  .fields([
    {
      name: "thumbnail",
      maxCount: "1"
    },
    {
      name: "banner",
      maxCount: 1
    },
    {
      name: "document",
      maxCount: 1
    },
  ])
app.get('/', function (req, res) {
  course.find(function (err, images) {
    if (err) {
      res.send({
        success: false,
        message: err.message
      })
    }
    else {
      res.send(images)
    }
  })
}).get('/:id', function (req, res) {

  course.findOne({ _id: req.params.id }, function (err, data) {
    if (err) {
      res.send({
        success: false,
        message: err.message
      })
    }
    else {
      res.send(data)
    }
  })
}).post('/', upload, (req, res, next) => {
  if (req.fileValidationError) {
    res.send({
      sucess: false,
      message: "Invalid Extension"
    })
  }
  else {
      const user = new course({
      title: req.body.title,
      description: req.body.description,
      thumbnail: req.files?.thumbnail[0].path,
      banner: req.files?.banner[0].path,
      document: req.files?.document[0].path,
      parent: req.body.parent,
      suitable: req.body.suitable,
      highlights: req.body.highlights,
      status: req.body.status
    });
    user.save(function (err) {
      if (err) {
        res.send({
          success: false,
          message: err.message
        })
      }
      else {
        res.send({
          success: true,
          message: "Created successfully "
        })
      }
    })
  }
}).put('/:id', upload, function (req, res) {
  let id = req.params.id
  var User_data = {
    title: req.body.title,
    description: req.body.description,
    thumbnail: req.files?.thumbnail[0].path,
    banner: req.files?.banner[0].path,
    document: req.files?.document[0].path,
    parent: req.body.parent,
    suitable: req.body.suitable,
    highlights: req.body.highlights
  }
  course.findByIdAndUpdate(id, User_data, function (error) {
    if (error) {
      res.send({
        success: false,
        message: error.message
      })
    } else {
      res.send({
        success: true,
        message: "Updated successfully"
      })
    }
  })
}).delete("/:id", (req, res) => {
  let _id = req.params.id
  course.findByIdAndDelete(_id, function (err) {
    if (err) {
      res.send({
        success: false,
        message: err.message
      })
    } else {
      res.send({
        sucess: true,
        message: "Deleted successfully"
      })
    }
  })
})
module.exports = app
