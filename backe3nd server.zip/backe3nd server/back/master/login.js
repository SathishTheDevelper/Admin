const express = require('express')
const app = express();
const jwt = require('jsonwebtoken');
const User = require('../models/user');
const secret = require('../token.js');
app.post('/', (req, res) => {
  User.findOne({
    $and: [{
      password: req.body.password
    }, {
      mobile_no: req.body.mobile_no
    }]
  }).then(user => {
    if (user) {
      const token_id = jwt.sign({ id: user._id }, secret);
      res.send({
        success: true,
        token: token_id
      });
    } else {
      res.send({
        success: false,
        message: "No user found"
      });
    }
  });
})
module.exports = app;