const express = require('express')
const app = express()
const registered_course = require('../models/registered-course')
app.get('/', function (req, res) {
    registered_course.find(function (err, user_data) {
        if (err) {
            res.send({
                success: false,
                message: err.message
            })
        }
        else {
            res.send(user_data)
        }
    })
}).get('/:id', function (req, res) {
registered_course.findOne({ _id: req.params.id }, function (err, user_data) {
        if (err) {
            res.send({
                success: false,
                message: err.message
            })
        }
        else {
            res.send(user_data)
        }
    })
}).post('/', (req, res, next) => {
    const user = new Registered_course({
        student_id: req.body.student_id,
        course_id: req.body.course_id,
        batch_id: req.body.batch_id,
        date_time: req.body.date_time,
        fees_amount: req.body.fees_amount,
        start_date: req.body.start_date,
        end_date: req.body.end_date
    });
    user.save(function (err) {
        if (err) {
            res.send({
                success: false,
                message: err.message
            })
        }
        else {
            res.send({
                success: true,
                message: "Created successfully"
            })
        }
    })
}).put('/:id', function (req, res) {
    let id = req.params.id
    var User_data = {
        student_id: req.body.student_id,
        course_id: req.body.course_id,
        batch_id: req.body.batch_id,
        date_time: req.body.date_time,
        fees_amount: req.body.fees_amount,
        start_date: req.body.start_date,
        end_date: req.body.end_date
    }
    registered_course.findByIdAndUpdate(id, User_data, function (error) {
        if (error) {
            res.send({
                success: false,
                message: error.message
            })
        }
        else {
            res.send({
                success: true,
                message: "Updated Successfully"
            })
        }
    })
}).delete('/:id', function (req, res) {
    let __id = req.params.id
    registered_course.findByIdAndDelete(__id, function (error) {
        if (error) {
            res.send({
                success: false,
                message: error.message
            })
        }
        else {
            res.send({
                sucess: true,
                message: "Deleted Successfully"
            })
        }
    })
})
module.exports = app
