const express = require('express')
const app = express();
const student_batch_allotment = require('../models/student-batch-allotment')
app.get('/', (req, res) => {
  student_batch_allotment.find(function (err, data) {
    if (err) {
      res.send({
        success: false,
        message: err.message
      })
    }
    else {
      res.send(data)
    }
  })
}).get('/:id', function (req, res) {
student_batch_allotment.findOne({ _id: req.params.id }, function (err, data) {
    if (err) {
      res.send({
        success: false,
        message: err.message
      })
    }
    else {
      res.send(data)
    }
  })
}).post('/', (req, res) => {
  const user = new student_batch_allotment({
    student_id: req.body.student_id,
    Course_id: req.body.Course_id,
    batch_id: req.body.batch_id,
    date_time: req.body.date_time
  });
  user.save(function (err) {
    if (err) {
      res.send({
        success: false,
        message: err.message
      })
    } else {
      res.send({
        success: true,
        message: "Created Successfully"
      })
    }
  })
}).put('/:id', function (req, res) {
  let id = req.params.id
  var User_data = {
    student_id: req.body.student_id,
    Course_id: req.body.Course_id,
    batch_id: req.body.batch_id,
    date_time: req.body.date_time
  }
  student_batch_allotment.findByIdAndUpdate(id, User_data, function (err) {
    if (err) {
      res.send({
        success: false,
        message: err.message
      })
    }
    else {
      res.send({
        success: true,
        message: "Updated Successfully"
      })
    }
  })
}).delete("/:id", (req, res) => {
  let _id = req.params.id
  student_batch_allotment.findByIdAndDelete(_id, function (err) {
    if (err) {
      res.send({
        success: false,
        message: err.message
      })
    }
    else {
      res.send({
        success: true,
        message: "Deleted Successfully"
      })
    }
  })
})
module.exports = app
