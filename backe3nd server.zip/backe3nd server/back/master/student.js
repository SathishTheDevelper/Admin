const express = require('express')
const app = express()
const Students = require('../models/student')
app.get('/', function (req, res) {
  Students.find(function (err, user_data) {
    if (err) {
    res.send({
        success: false,
        message: err.message
      })
    }
    else {
      res.send(user_data)
    }
  })
}).get('/:id', function (req, res) {

  Students.findOne({ _id: req.params.id }, function (err, student_data) {
    if (err) {
      res.send({
        success: false,
        message: err.message
      })
    }
    else {
      res.send(student_data)
    }
  })
}).post('/', (req, res, next) => {
  const user = new Students({
    first_name: req.body.first_name,
    last_name: req.body.last_name,
    date_of_birth: req.body.date_of_birth,
    mobile_no: req.body.mobile_no,
    password: req.body.password,
    gender: req.body.gender,
    email: req.body.email,
    citizenship: req.body.citizenship,

    father: req.body.father,
    name: req.body.name,
    occupation: req.body.occupation,
    contact_no: req.body.contact_no,

    mother: req.body.mother,
    name: req.body.name,
    occupation: req.body.occupation,
    contact_no: req.body.contact_no,

    guardian: req.body.guardian,
    name: req.body.name,
    occupation: req.body.occupation,
    contact_no: req.body.contact_no,

    permanent_address: req.body.permanent_address,

    address_line_1: req.body.address_line_1,
    address_line_2: req.body.address_line_2,
    state: req.body.state,
    city: req.body.city,
    area: req.body.area,
    pincode: req.body.pincode,

    temperory_address: req.body.temperory_address,
    address_line_1: req.body.address_line_1,
    address_line_2: req.body.address_line_2,
    state: req.body.state,
    city: req.body.city,
    area: req.body.area,
    pincode: req.body.pincode,

    education_qualification: req.body.education_qualification,

    qualification: req.body.qualification,
    medium_of_study: req.body.medium_of_study,
    board_of_studies: req.body.board_of_studies,
    percentage: req.body.percentage,
    grade: req.body.grade,

    status: req.body.status
  })
  user.save(function (err) {
    if (err) {
      res.send({
        success: false,
        message: err.message
      })
    } else {
      res.send({
        success: true,
        message: "Created Successfully"
      })
    }
  })
}).put('/:id', function (req, res) {
  let id = req.params.id
  var student_user_update = {
    first_name: req.body.first_name,
    last_name: req.body.last_name,
    date_of_birth: req.body.date_of_birth,
    mobile_no: req.body.mobile_no,
    password: req.body.password,
    gender: req.body.gender,
    email: req.body.email,
    citizenship: req.body.citizenship,

    father: req.body.father,
    name: req.body.name,
    occupation: req.body.occupation,
    contact_no: req.body.contact_no,

    mother: req.body.mother,
    name: req.body.name,
    occupation: req.body.occupation,
    contact_no: req.body.contact_no,

    guardian: req.body.guardian,
    name: req.body.name,
    occupation: req.body.occupation,
    contact_no: req.body.contact_no,

    permanent_address: req.body.permanent_address,

    address_line_1: req.body.address_line_1,
    address_line_2: req.body.address_line_2,
    state: req.body.state,
    city: req.body.city,
    area: req.body.area,
    pincode: req.body.pincode,

    temperory_address: req.body.temperory_address,
    address_line_1: req.body.address_line_1,
    address_line_2: req.body.address_line_2,
    state: req.body.state,
    city: req.body.city,
    area: req.body.area,
    pincode: req.body.pincode,

    education_qualification: req.body.education_qualification,

    qualification: req.body.qualification,
    medium_of_study: req.body.medium_of_study,
    board_of_studies: req.body.board_of_studies,
    percentage: req.body.percentage,
    grade: req.body.grade,

    status: req.body.status
  }
  Students.findByIdAndUpdate(id, student_user_update, function (error) {
    if (error) {
      res.send({
        success: false,
        message: error.message
      })
    }
    else {
      res.send({
        sucess: true,
        message: "Updated successfully"
      })
    }
  })
}).delete("/:id", (req, res) => {
  let _id = req.params.id
  Students.findByIdAndDelete(_id, function (err) {
    if (err) {
      res.send({
        success: false,
        message: err.message
      })
    }
    else {
      res.send({
        Success: true,
        message: "Deleted Successfully"
      })
    }
  })
})
module.exports = app