const express = require('express')
const app = express();
const multer = require('multer')
const topic_sub = require('../models/topic-sub')
const storage = multer.diskStorage({
  destination: ('image'),
  filename: function (req, file, callback) {

    callback(null, file.originalname);
  }
});
var upload = multer({
  storage: storage,
  fileFilter: function (req, file, cb) {
    if (file.mimetype == "image/png" || file.mimetype == "image/jpg" || file.mimetype == "image/jpeg") {
      cb(null, true);
    } else {
      req.fileValidationError = "Forbidden extension";
      return cb(null, false, req.fileValidationError);
    }
  }
});
app.get('/', (req, res) => {
  topic_sub.find(function (err, data) {
    if (err) {
      res.send({
        success: false,
        message: err.message
      })
    }
    else {
      res.send(data)
    }
  })
}).get('/:id', function (req, res) {

  topic_sub.findOne({ _id: req.params.id }, function (err, data) {
    if (err) {
      res.send({
        success: false,
        message: err.message
      })
    }
    else {
      res.send(data)
    }
  })
}).post('/', upload.single('path'), (req, res) => {
  if (req.fileValidationError) {
    res.send({
      sucess: false,
      message: "Error: Only .png, .jpg and .jpeg format allowed!"
    })
  }
  else {
    const user = new topic_sub({
      file_type: req.body.file_type,
      path: req.file.path,
      link: req.body.link,
      topic_id: req.body.topic_id,
      order_no: req.body.order_no
    });
    user.save(function (err) {
      if (err) {
        res.send({
          success: false,
          message: err.message
        })
      }
      else {
        res.send({
          success: true,
          message: "Created Successfully"
        })
      }
    })
  }
}).put('/:id', upload.single('path'), function (req, res) {
  let id = req.params.id
  var User_data = {
    file_type: req.body.file_type,
    path: req.file.path,
    link: req.body.link,
    topic_id: req.body.topic_id,
    order_no: req.body.order_no
  }
  topic_sub.findByIdAndUpdate(id, User_data, function (err) {
    if (err) {
      res.send({
        success: false,
        message: err.message
      })
    }
    else {
      res.send({
        success: true,
        message: "Updated Successfully"
      })
    }
  })
}).delete("/:id", (req, res) => {
  let _id = req.params.id
  topic_sub.findByIdAndDelete(_id, function (err) {
    if (err) {
      res.send({
        success: false,
        message: err.message
      })
    }
    res.send({
      success: true,
      message: "Deleted Successfully"
    })
  })
})
module.exports = app

