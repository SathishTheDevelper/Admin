const express = require('express');
const app = express();
const topic = require('../models/topic');
app.get('/', (req, res) => {
  topic.find(function (err, data) {
    if (err) {
      res.send({
        success: false,
        message: err.message
      })
    }
    else {
      res.send(data)
    }
  })
}).get('/:id', function (req, res) {
  topic.findOne({ _id: req.params.id }, function (err, data) {
    if (err) {
      res.send({
        success: false,
        message: err.message
      })
    }
    else {
      res.send(data)
    }
  })
}).post('/', (req, res) => {
  const user = new topic({
    title: req.body.title,
    parent: req.body.parent,
    description: req.body.description,
    key_word: req.body.key_word
  });
  user.save(function (err) {
    if (err) {
      res.send({
        success: false,
        message: err.message
      })
    } else {
      res.send({
        success: true,
        message: "Created Successfully"
      })
    }
  })
}).put('/:id', function (req, res) {
  let id = req.params.id
  var User_data = {
    title: req.body.title,
    parent: req.body.parent,
    description: req.body.description,
    key_word: req.body.key_word
  }
  topic.findByIdAndUpdate(id, User_data, function (err, user_name) {
    if (err) {
      res.send({
        success: false,
        message: err.message
      })
    }
    else {
      res.send({
        success: true,
        message: "Updated Successfully"
      })
    }
  })
}).delete("/:id", (req, res) => {
  let _id = req.params.id
  topic.findByIdAndDelete(_id, function (err) {
    if (err) {
      res.send({
        success: false,
        message: err.message
      })
    } else {
      res.send({
        sucess: true,
        message: "Deleted successfully"
      })
    }
  })
})
module.exports = app