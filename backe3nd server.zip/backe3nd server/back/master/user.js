const express = require('express')
const app = express()
const Users = require('../models/user')
app.get('/', function (req, res) {
    Users.find(function (err, user_data) {
        if (err) {
            res.send({
                success: false,
                message: err.message
            })
        }
        else {
            res.send(user_data)
        }
    })
}).get('/:id', function (req, res) {
Users.findOne({ _id: req.params.id }, function (err, user_data) {
        if (err) {
            res.send({
                success: false,
                message: err.message
            })
        }
        else {
            res.send(user_data)
        }
    })
}).post('/', (req, res, next) => {
    const user = new Users({
        user_name: req.body.user_name,
        password: req.body.password,
        email: req.body.email,
        mobile_no: req.body.mobile_no,
        role: req.body.role,
        status: req.body.status
    });
    user.save(function (err) {
        if (err) {
            res.send({
                success: false,
                message: err.message
            })
        }
        else {
            res.send({
                success: true,
                message: "Created Successfully"
            })
        }
    })
}).put('/:id', function (req, res) {
    let id = req.params.id
    var User_data = {
        user_name: req.body.user_name,
        password: req.body.password,
        mobile_no: req.body.mobile_no,
        role: req.body.role,
        email: req.body.email,
        status: req.body.status
    }
    Users.findByIdAndUpdate(id, User_data, function (error) {
        if (error) {
            res.send({
                success: false,
                message: error.message
            })
        }
        else {
            res.send({
                sucess: true,
                message: "Updated Successfully"
            })
        }
    })
}).delete('/:id', function (req, res) {
    let _id = req.params.id
    Users.findByIdAndDelete(_id, function (error) {
        if (error) {
            res.send({
                success: false,
                message: error.message
            })
        }
        else {
            res.send({
                success: true,
                message: "Deleted Successfully"
            })
        }
    })
})
module.exports = app