const mongoose = require('mongoose')
var Schema = mongoose.Schema;
var bannerSchema = new Schema({
        path: String,
        caption: String,
        status: {type: Boolean,default: true}
})
module.exports = mongoose.model('banner', bannerSchema)
