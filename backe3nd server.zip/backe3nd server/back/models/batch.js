const mongoose = require('mongoose')
const batchSchema = new mongoose.Schema({
    course_id: {type: mongoose.Schema.Types.ObjectId,ref: 'course'},
    title: {type: String,},
    description: {type: String,},
    mode: {type: String,enum: ['online', 'offline'],default: 'online'},
    start_time: {type: Date},
    end_time: {type: Date},
    fees_amount: {type: Number},
    min_students: {type: Number},
    max_students: {type: Number},
    staff: [{type: String}],
    alternative_staff: [{type: String}],
    status: {type: Boolean,default: true},
})
const batch = mongoose.model('batch', batchSchema)
module.exports = batch
