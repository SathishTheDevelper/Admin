const mongoose = require('mongoose')
var Schema = mongoose.Schema;
var courseSchema = new Schema({
    title: {type: String,required: true},
    description: {type: String,required: true},
    thumbnail: {type: String},
    banner: {type: String },
    document: {type: String},
    parent: String,
    suitable: [{type: String}],
    highlights: [{type: String}],
    status: {type: Boolean,default: true}
})
module.exports = mongoose.model('course', courseSchema)
