const mongoose = require('mongoose')
var Schema = mongoose.Schema;
var registered_courseSchema = new Schema({
    student_id: { required: true, type: mongoose.Schema.Types.ObjectId, ref: 'student' },
    batch_id: { required: true, type: mongoose.Schema.Types.ObjectId, ref: 'batch' },
    course_id: { required: true, type: mongoose.Schema.Types.ObjectId, ref: 'course' },
    date_time: Date,
    fees_amount: Number,
    start_date: Date,
    end_date: Date
})
module.exports = mongoose.model('registered_course', registered_courseSchema)
