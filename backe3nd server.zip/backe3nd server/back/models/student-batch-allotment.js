const mongoose = require('mongoose')
const studentSchema = new mongoose.Schema({
    student_id: { type: mongoose.Schema.Types.ObjectId },
    Course_id: { type: mongoose.Schema.Types.ObjectId },
    batch_id: { type: mongoose.Schema.Types.ObjectId },
    date_time: { type: String }
})
const student_batch_allotment = mongoose.model('student_batch_allotment', studentSchema)
module.exports = student_batch_allotment
