const mongoose = require('mongoose')
var Schema = mongoose.Schema
var studentSchema = new Schema({
	first_name: { type: String, required: true },
	last_name: { type: String },
	date_of_birth: { type: Date, required: true },
	mobile_no: { type: Number, required: true, unique: true },
	password: { type: String, required: true },
	gender: { type: String, required: true },
	email: { type: String, required: true, unique: true },
	citizenship: { type: String, required: true },
	father: { name: { type: String }, occupation: { type: String }, contact_no: { type: Number } },
	mother: { name: { type: String }, occupation: { type: String }, contact_no: { type: Number } },
	guardian: { name: { type: String }, occupation: { type: String }, contact_no: { type: Number } },
	permanent_address: { address_line_1: { type: String, required: true }, address_line_2: { type: String }, state: { type: String, required: true }, city: { type: String, required: true }, area: { type: String, required: true }, pincode: { type: Number, required: true } },
	temperory_address: { address_line_1: { type: String, required: true }, address_line_2: { type: String }, state: { type: String, required: true }, city: { type: String, required: true }, area: { type: String, required: true }, pincode: { type: Number, required: true } },
	education_qualification: [{ qualification: { type: String }, medium_of_study: { type: String }, board_of_studies: { type: String }, percentage: { type: Number }, grade: { type: String }, }],
	status: { type: Boolean, default: true }
})
module.exports = mongoose.model('student', studentSchema)