const mongoose = require('mongoose')
const topicsubSchema = new mongoose.Schema({
    file_type: { type: String },
    path: { type: String },
    link: { type: String },
    topic_id: { type: mongoose.Schema.Types.ObjectId, ref: 'topic' },
    order_no: { type: Number },
})
const topic_sub = mongoose.model('topic_sub', topicsubSchema)
module.exports = topic_sub
