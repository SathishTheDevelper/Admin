const mongoose = require('mongoose')
const topicSchema = new mongoose.Schema({
    title: { type: String },
    parent: { type: String },
    description: { type: String },
    key_word: [{ type: String }],
})
const topic = mongoose.model('topic', topicSchema)
module.exports = topic
