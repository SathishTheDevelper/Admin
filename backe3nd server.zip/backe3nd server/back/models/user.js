const mongoose = require('mongoose')
var Schema = mongoose.Schema;
var UserSchema = new Schema({
    user_name: { type: String, required: true },
    password: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    mobile_no: { type: Number, required: true, unique: true },
    role: { type: String },
    status: { type: Boolean, default: true }
})
module.exports = mongoose.model('user', UserSchema)