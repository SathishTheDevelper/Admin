const express = require('express')
const app = express();
const tokens = 'Bla@2021@LMS@#$%990003';
module.export=app