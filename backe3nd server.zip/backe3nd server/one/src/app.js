"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
//import multer from "multer";
//import { GridFsStorage } from "multer-gridfs-storage";
const mongoose_1 = require("mongoose");
const index_1 = __importDefault(require("./routes/index"));
const dotenv_1 = __importDefault(require("dotenv"));
const cors_1 = __importDefault(require("cors"));
const http_1 = __importDefault(require("http"));
const https_1 = __importDefault(require("https"));
const path_1 = __importDefault(require("path"));
const fs_1 = require("fs");
dotenv_1.default.config();
process.env.TZ = "Asia/Kolkata";
const port = process.env.PORT;
const app = (0, express_1.default)();
process.env.URL = "localhost:27017/" + process.env.DB;
(0, mongoose_1.connect)(`mongodb://localhost:27017`, {
    dbName: process.env.DB,
});
app.use((0, cors_1.default)());
app.use(express_1.default.json());
app.use(express_1.default.urlencoded({ extended: true }));
app.use(express_1.default.urlencoded({ extended: true }));
app.use('/public', express_1.default.static('./public'));
mongoose_1.connection.on("error", console.error.bind(console, "connection error:"));
mongoose_1.connection.once("open", function () {
    console.log("connected to db");
});
app.use(index_1.default);
if (process.env.configuration == "prod") {
    const options = {
        key: (0, fs_1.readFileSync)(path_1.default.join(process.cwd(), "../../etc/letsencrypt/live/www.getbullionnews.com/privkey.pem"), "utf8"),
        cert: (0, fs_1.readFileSync)(path_1.default.join(process.cwd(), "../../etc/letsencrypt/live/www.getbullionnews.com/fullchain.pem"), "utf8"),
    };
    https_1.default.createServer(options, app).listen(port, () => {
        console.log(`Server running on PORT: ${port}`);
    });
}
else {
    http_1.default.createServer(app).listen(port);
}
