"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const currency_service_1 = __importDefault(require("../services/currency-service"));
const common_route_1 = require("../utils/common-route");
let routes = new common_route_1.CommonRoutes(currency_service_1.default);
const CurrencyController = (0, express_1.Router)();
CurrencyController.get('/', routes.list)
    .get('/:id', routes.retrieve)
    .post('/', routes.add)
    .put('/:id', routes.update)
    .delete('/:id', routes.delete);
exports.default = CurrencyController;
