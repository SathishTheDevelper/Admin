"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const export_booking_service_1 = __importDefault(require("../services/export-booking-service"));
const common_route_1 = require("../utils/common-route");
let routes = new common_route_1.CommonRoutes(export_booking_service_1.default);
const getBookingReference = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        let exportBookingService = new export_booking_service_1.default();
        res.json(yield exportBookingService.bookingReference(req.body.date));
    }
    catch (error) {
        res.json({ success: false, message: error.message });
    }
});
const ExportBookingController = (0, express_1.Router)();
ExportBookingController.get("/", routes.list)
    .get("/:id", routes.retrieve)
    .post("/get-bookingno", getBookingReference)
    .post("/", routes.add)
    .put("/:id", routes.update)
    .post("/approve/:id", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        let ser = new export_booking_service_1.default();
        res.json(yield ser.approve(req.params.id, req.body.stage, ""));
    }
    catch (error) {
        res.json({ success: false, message: error.message });
    }
}))
    .delete("/:id", routes.delete);
exports.default = ExportBookingController;
