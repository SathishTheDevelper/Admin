"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const dotenv_1 = __importDefault(require("dotenv"));
const express_1 = require("express");
const multer_1 = __importDefault(require("multer"));
const multer_gridfs_storage_1 = require("multer-gridfs-storage");
dotenv_1.default.config();
const url = "mongodb://" + process.env.URL + process.env.DB;
let storage = new multer_gridfs_storage_1.GridFsStorage({
    url: url,
    file: (req, file) => {
        return {
            bucketName: "attachment",
            filename: file.originalname, //Setting file name to original name of file
        };
    },
});
let upload = (0, multer_1.default)({ storage });
const FileAttachmentController = (0, express_1.Router)();
FileAttachmentController
    .get("/", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
    }
    catch (error) {
    }
}))
    .post("/", upload.array("file"), (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const { file } = req;
    res.send(req.files);
}));
exports.default = FileAttachmentController;
