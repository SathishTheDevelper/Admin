"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const fs_1 = require("fs");
const multer_1 = __importDefault(require("multer"));
const party_attachment_service_1 = __importDefault(require("../services/party-attachment-service"));
const common_route_1 = require("../utils/common-route");
const path_1 = __importDefault(require("path"));
if (!(0, fs_1.existsSync)('public'))
    (0, fs_1.mkdirSync)('public');
if (!(0, fs_1.existsSync)('public/party-attachment'))
    (0, fs_1.mkdirSync)('public/party-attachment');
const storage = multer_1.default.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'public/party-attachment');
    },
    filename: function (req, file, cb) {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, file.fieldname + '-' + uniqueSuffix + path_1.default.extname(file.originalname));
    }
});
let upload = (0, multer_1.default)({ storage: storage });
let routes = new common_route_1.CommonRoutes(party_attachment_service_1.default);
const PartyAttachmentController = (0, express_1.Router)();
PartyAttachmentController.get("/", routes.list)
    .get("/:id", routes.retrieve)
    .post('/', upload.single("files"), (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    try {
        let ser = new party_attachment_service_1.default();
        res.json(yield ser.add(Object.assign(Object.assign({}, req.body), { files: (_a = req.file) === null || _a === void 0 ? void 0 : _a.path })));
    }
    catch (error) {
        res.json({ success: false, error: error.message });
    }
}))
    .put('/:id', upload.single("files"), (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _b;
    try {
        let ser = new party_attachment_service_1.default();
        let data = Object.assign({}, req.body);
        if (req.files) {
            let files = req.files;
            data = Object.assign(Object.assign({}, data), { files: (_b = req.file) === null || _b === void 0 ? void 0 : _b.path });
        }
        res.json(yield ser.updateById(data, req.params.id));
    }
    catch (error) {
        res.json({ success: false, error: error.message });
    }
}))
    .delete("/:id", routes.delete);
exports.default = PartyAttachmentController;
