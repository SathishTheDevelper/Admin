"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const role_service_1 = __importDefault(require("../services/role-service"));
const common_route_1 = require("../utils/common-route");
let routes = new common_route_1.CommonRoutes(role_service_1.default);
const RoleController = (0, express_1.Router)();
RoleController.get('/', routes.list)
    .get('/:id', routes.retrieve)
    .post('/', routes.add)
    .put('/:id', routes.update)
    .delete('/:id', routes.delete);
exports.default = RoleController;
