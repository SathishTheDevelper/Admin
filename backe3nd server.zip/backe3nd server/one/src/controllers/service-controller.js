"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const service_service_1 = __importDefault(require("../services/service-service"));
const common_route_1 = require("../utils/common-route");
let routes = new common_route_1.CommonRoutes(service_service_1.default);
const ServiceController = (0, express_1.Router)();
ServiceController.get('/', routes.list)
    .get('/:id', routes.retrieve)
    .post('/', routes.add)
    .put('/:id', routes.update)
    .delete('/:id', routes.delete);
exports.default = ServiceController;
