"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
let AccessMenuSchema = new mongoose_1.Schema({
    menu_name: { type: String, required: true, trim: true, unique: false },
    route: String,
    module: { type: mongoose_1.Schema.Types.ObjectId, ref: "access_module" },
    options: [{ type: mongoose_1.Schema.Types.ObjectId, ref: "access_option" }],
    order_no: Number,
    status: { type: Boolean, default: true },
}, {
    timestamps: true,
});
exports.default = (0, mongoose_1.model)("access_menu", AccessMenuSchema);
