"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
let AccessModuleSchema = new mongoose_1.Schema({
    module_name: { type: String, required: true, trim: true },
    icon: String,
    parent: { type: mongoose_1.Schema.Types.ObjectId, ref: 'access_module' },
    order_no: Number,
    route: String,
    status: { type: Boolean, default: true },
}, {
    timestamps: true,
});
exports.default = (0, mongoose_1.model)('access_module', AccessModuleSchema);
