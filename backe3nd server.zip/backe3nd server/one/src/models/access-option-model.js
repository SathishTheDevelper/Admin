"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
let AccessOptionSchema = new mongoose_1.Schema({
    option_name: { type: String, required: true, unique: true, trim: true },
    order_no: Number,
    status: { type: Boolean, default: true },
}, {
    timestamps: true,
});
exports.default = (0, mongoose_1.model)('access_option', AccessOptionSchema);
