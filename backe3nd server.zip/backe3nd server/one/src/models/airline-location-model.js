"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const airlineLocationSchema = new mongoose_1.Schema({
    name: { type: String, required: true, trim: true, uppercase: true },
    airline_name: { type: String },
    country_name: { type: String },
    code: { type: String },
    accounting_code: { type: String },
    prefix_code: { type: String },
    status: { type: Boolean, default: true },
}, {
    timestamps: true,
});
exports.default = (0, mongoose_1.model)("airline_location", airlineLocationSchema);
