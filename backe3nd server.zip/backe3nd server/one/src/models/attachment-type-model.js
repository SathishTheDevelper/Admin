"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const attachmentTypeSchema = new mongoose_1.Schema({
    code: {
        type: String,
        required: true,
        trim: true,
        unique: true,
        uppercase: true,
    },
    description: String,
    is_customer_share: { type: Boolean, default: false },
    active: { type: Boolean, default: true },
}, {
    timestamps: true,
});
exports.default = (0, mongoose_1.model)("attachment_type", attachmentTypeSchema);
