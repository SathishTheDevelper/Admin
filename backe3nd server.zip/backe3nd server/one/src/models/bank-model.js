"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const bankSchema = new mongoose_1.Schema({
    account_holder_name: { type: String },
    account_no: { type: String },
    bank_name: String,
    branch_name: String,
    ifsc: String,
    default_bank: { type: Boolean, default: false },
    status: { type: Boolean, default: true },
}, {
    timestamps: true,
});
exports.default = (0, mongoose_1.model)("bank", bankSchema);
