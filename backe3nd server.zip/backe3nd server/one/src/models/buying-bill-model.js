"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const buyingBillSchema = new mongoose_1.Schema({
    code: {
        type: String,
        required: true,
        trim: true,
        unique: true,
        uppercase: true,
    },
    name: { type: String, required: true, trim: true },
    status: { type: Boolean, default: true },
}, {
    timestamps: true,
});
exports.default = (0, mongoose_1.model)("buying_bill", buyingBillSchema);
