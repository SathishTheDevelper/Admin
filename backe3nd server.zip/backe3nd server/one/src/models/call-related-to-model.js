"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const callRelatedToSchema = new mongoose_1.Schema({
    name: { type: String, required: true, trim: true, uppercase: true, unique: true },
    status: { type: Boolean, default: true },
    done_by: { type: mongoose_1.Schema.Types.ObjectId, ref: 'user' },
}, {
    timestamps: true,
});
exports.default = (0, mongoose_1.model)("call_related_to", callRelatedToSchema);
