"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const callScheduleMeetingSchema = new mongoose_1.Schema({
    meeting_id: { type: String, required: true, trim: true, unique: true },
    subject: { type: String, required: true, trim: true },
    description: { type: String },
    call_status: { type: mongoose_1.Schema.Types.ObjectId, ref: 'call_status' },
    related_to: { type: mongoose_1.Schema.Types.ObjectId, ref: 'call_related_to' },
    duration: { type: Number },
    start_date: { type: Date, required: true },
    reminder: { type: Date, required: true },
    invites: [{ type: mongoose_1.Schema.Types.ObjectId, ref: 'party' }],
    done_by: { type: mongoose_1.Schema.Types.ObjectId, ref: 'user' },
}, {
    timestamps: true,
});
exports.default = (0, mongoose_1.model)("call_schedule_meeting", callScheduleMeetingSchema);
