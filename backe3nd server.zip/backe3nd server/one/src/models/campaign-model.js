"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.campaignAttachmentsModel = exports.campaignForModel = exports.campaignModel = void 0;
const mongoose_1 = require("mongoose");
const campaignSchema = new mongoose_1.Schema({
    c_no: Number,
    c_year: {
        type: String,
        trim: true,
        required: true,
        length: 2,
        uppercase: true,
    },
    c_month: {
        type: String,
        trim: true,
        required: true,
        length: 2,
        uppercase: true,
    },
    campaign_no: { type: String, trim: true, unique: true, required: true },
    type: { type: String, enum: ["Mail", "SMS", "Whatsapp"] },
    targetType: { type: String, enum: ["Walkin", "Customer"] },
    subject: { type: String, trim: true },
    content: { type: String, trim: true },
    campaign_date: { type: Date, required: true },
    campaign_mode: { type: String, enum: ["Auto", "Manual"], default: "Auto" },
    done_by: { type: mongoose_1.Schema.Types.ObjectId, ref: "user" },
    close: { type: Boolean, default: false },
    status: { type: Boolean, default: true },
}, {
    timestamps: true,
});
exports.campaignModel = (0, mongoose_1.model)("campaign", campaignSchema);
const campaignForSchema = new mongoose_1.Schema({
    campaign: { type: mongoose_1.Schema.Types.ObjectId, ref: "campaign" },
    customer: { type: mongoose_1.Schema.Types.ObjectId, ref: "party" },
    walkin: { type: mongoose_1.Schema.Types.ObjectId, ref: "walkin" },
    date_time: { type: Date, default: Date.now },
}, {
    timestamps: true,
});
exports.campaignForModel = (0, mongoose_1.model)("campaign_for", campaignForSchema);
const campaignAttachmentsSchema = new mongoose_1.Schema({
    campaign: { type: mongoose_1.Schema.Types.ObjectId, ref: "campaign" },
    file: String,
}, {
    timestamps: true,
});
exports.campaignAttachmentsModel = (0, mongoose_1.model)("campaign_attachments", campaignAttachmentsSchema);
