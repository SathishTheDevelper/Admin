"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const chargeTypeSchema = new mongoose_1.Schema({
    code: { type: String, required: true, trim: true, unique: true, uppercase: true },
    name: { type: String, required: true, trim: true },
    accounting_name: String,
    shipment_type: [String],
    is_tax_applicable: { type: Boolean, default: false },
    tax_percentage: Number,
    rate: Number,
    tax_id: { type: mongoose_1.Schema.Types.ObjectId, ref: 'tax' },
    currency: { type: mongoose_1.Schema.Types.ObjectId, ref: 'currency' },
    unit: [{ type: mongoose_1.Schema.Types.ObjectId, ref: 'unit' }],
    sequence_no: String,
    mode: [{ type: String, enum: ['buying', 'selling'] }],
    status: { type: Boolean, default: true },
}, {
    timestamps: true,
});
exports.default = (0, mongoose_1.model)('charge_type', chargeTypeSchema);
