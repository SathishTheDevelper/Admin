"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const districtSchema = new mongoose_1.Schema({
    name: { type: String, required: true, trim: true, uppercase: true },
    state: { type: mongoose_1.Schema.Types.ObjectId, ref: 'state' },
    description: String,
    latitude: String,
    longitude: String,
    status: { type: Boolean, default: true },
}, {
    timestamps: true,
});
exports.default = (0, mongoose_1.model)('district', districtSchema);
