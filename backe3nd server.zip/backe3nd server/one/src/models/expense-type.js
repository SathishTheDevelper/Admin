"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const expenseTypeSchema = new mongoose_1.Schema({
    name: { type: String, required: true, trim: true, uppercase: true },
    list_in: [{ type: String, enum: ['Transport', 'Voucher'] }],
    status: { type: Boolean, default: true },
}, {
    timestamps: true,
});
exports.default = (0, mongoose_1.model)('expense_type', expenseTypeSchema);
