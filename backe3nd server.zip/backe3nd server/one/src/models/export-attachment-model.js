"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const exportAttachmentSchema = new mongoose_1.Schema({
    export_booking_id: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: "export_booking",
        required: true,
    },
    attachment_type: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: "attachment_type",
        required: true,
    },
    file: String,
}, {
    timestamps: true,
});
exports.default = (0, mongoose_1.model)("export_attachment", exportAttachmentSchema);
