"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const exportAwbSchema = new mongoose_1.Schema({
    export_booking_id: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: "export_booking",
        required: true,
    },
    hawb_no: String,
    hawb_date: Date,
    mawb_no: String,
    mawb_date: Date,
    tarrif_amount: Number,
});
exports.default = (0, mongoose_1.model)("export_awb", exportAwbSchema);
