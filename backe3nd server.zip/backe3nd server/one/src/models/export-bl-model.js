"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const exportBlSchema = new mongoose_1.Schema({
    export_booking_id: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: "export_booking",
        required: true,
    },
    hbl_no: String,
    hbl_date: Date,
    mbl_no: String,
    mbl_date: Date,
    obl_no: String,
    obl_date: Date,
    si_received_date: Date,
});
exports.default = (0, mongoose_1.model)("export_bl", exportBlSchema);
