"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const exportBookingSchema = new mongoose_1.Schema({
    b_no: { type: Number, required: true },
    b_year: { type: String, required: true },
    b_month: { type: String, required: true },
    booking_no: { type: String, required: true },
    booking_ref: { type: String, required: true },
    date: { type: Date, required: true },
    shipper: { type: mongoose_1.Schema.Types.ObjectId, ref: "party", required: true },
    consignee: { type: mongoose_1.Schema.Types.ObjectId, ref: "party", required: true },
    orgin_port: { type: mongoose_1.Schema.Types.ObjectId, ref: "seaport", required: true },
    loading_port: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: "seaport",
        required: true,
    },
    discharge_port: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: "seaport",
        required: true,
    },
    destination_port: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: "seaport",
        required: true,
    },
    shipment_type: String,
    no_of_packages: Number,
    no_of_cbm: Number,
    net_weight: Number,
    gross_weight: Number,
    package_type: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: "package_type",
        required: true,
    },
    cargo_type: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: "cargo_type",
        required: true,
    },
    payment_type: { type: String, enum: ["Paid", "To Pay"], required: true },
    nature_of_contract: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: "nature_of_contract",
        required: true,
    },
    service_provided: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: "service",
        required: true,
    },
    incoterms: { type: mongoose_1.Schema.Types.ObjectId, ref: "incoterms" },
    stage: String,
}, {
    timestamps: true,
});
exports.default = (0, mongoose_1.model)("export_booking", exportBookingSchema);
