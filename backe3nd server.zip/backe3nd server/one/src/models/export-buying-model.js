"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const exportBuyingSchema = new mongoose_1.Schema({
    export_booking_id: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: "export_booking",
        required: true,
    },
    agent: { type: String, enum: ["FFR", "CHA"] },
    buying_bill: { type: mongoose_1.Schema.Types.ObjectId, ref: "buying_bill" },
    invoice_no: String,
    invoice_date: Date,
    payable_to: { type: mongoose_1.Schema.Types.ObjectId, ref: "party" },
    address: String,
    is_proforma: { type: Boolean, default: false },
    third_party: { type: Boolean, default: false },
    branch: String,
    tds_percentage: Number,
    is_igst: { type: Boolean, default: false },
    is_customer_directly_paid: { type: Boolean, default: false },
    remark: String,
    item: [
        {
            charge_type: {
                type: mongoose_1.Schema.Types.ObjectId,
                ref: "charge_type",
            },
            description: String,
            rate: Number,
            quantity: Number,
            exchange_rate: Number,
            amount: Number,
            currency: { type: mongoose_1.Schema.Types.ObjectId, ref: "currency" },
            is_tax_applicable: { type: Boolean, default: false },
        },
    ], stage: String,
});
exports.default = (0, mongoose_1.model)("export_buying", exportBuyingSchema);
