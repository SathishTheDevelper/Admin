"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const exportContainerSchema = new mongoose_1.Schema({
    export_booking_id: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: "export_booking",
        required: true,
    },
    transport_planning: {
        factory_cfs: { type: mongoose_1.Schema.Types.ObjectId, ref: "party" }, //Doubt
    },
    container_details: {
        container: { type: mongoose_1.Schema.Types.ObjectId, ref: "container" },
        container_no: String,
        ownership: { type: String, enum: ["Linear", "Shipper"] },
        invoice_no: { type: mongoose_1.Schema.Types.ObjectId, ref: "export_invoice" },
    },
    packages_and_weight_details: {
        no_of_packing: Number,
        package_type: { type: mongoose_1.Schema.Types.ObjectId, ref: "package_type" },
        empty_weight: Number,
        gross_weight: Number,
        net_weight: Number,
        excess_weight: Number,
        unit: String,
        volume: Number,
        max_payload_weight: Number,
    },
    seal_details: {
        linear: String,
        custom: String,
        excise: String,
        excise_date: Date,
    },
    survey_and_fumigation_details: {
        survey_date: Date,
        fumigation_date: Date,
    },
    plot_panel: {
        plot: { type: mongoose_1.Schema.Types.ObjectId, ref: "plot" },
        plot_in: Date,
        plot_out: Date,
        plot_halting_days: Number,
    },
    factory_panel: {
        factory: { type: mongoose_1.Schema.Types.ObjectId, ref: "party" },
        factory_in: Date,
        factory_out: Date,
        factory_halting_days: Number,
    },
    cfs_panel: {
        cfs: { type: mongoose_1.Schema.Types.ObjectId, ref: "party" },
        cfs_in: Date,
        cfs_out: Date,
        cfs_halting_days: Number,
        clearance_type: { type: mongoose_1.Schema.Types.ObjectId, ref: "clearance_type" },
        stuffing_date: Date,
        customs_clearance: Date,
    },
    port_panel: {
        terminal_in: Date,
        terminal_out: Date,
        terminal_halting_days: Number,
        terminal: { type: mongoose_1.Schema.Types.ObjectId, ref: "terminal" },
    },
    stage: String,
}, {
    timestamps: true,
});
exports.default = (0, mongoose_1.model)("export_container", exportContainerSchema);
