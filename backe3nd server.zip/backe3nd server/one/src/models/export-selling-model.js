"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const exportSellingSchema = new mongoose_1.Schema({
    export_booking_id: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: "export_booking",
        required: true,
    },
    agent: { type: String, enum: ["FFR", "CHA"] },
    charge_type: { type: mongoose_1.Schema.Types.ObjectId, ref: "charge_type" },
    description: String,
    rate: Number,
    currency: { type: mongoose_1.Schema.Types.ObjectId, ref: "currency" },
    unit: String,
    quantity: Number,
    ex_rate: Number,
    net_total: Number,
    tax_percentage: Number,
    is_tax: { type: Boolean, default: false },
    gross_total: Number,
    payable_by: String,
    tot_tax_amount: Number,
    remark: String,
    stage: String,
}, {
    timestamps: true,
});
exports.default = (0, mongoose_1.model)("export_selling", exportSellingSchema);
