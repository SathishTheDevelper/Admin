"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const exportShippingBillSchema = new mongoose_1.Schema({
    export_booking_id: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: "export_booking",
        required: true,
    },
    sb_no: String,
    sb_date: Date,
    fob_value: Number,
    fob_currency: { type: mongoose_1.Schema.Types.ObjectId, ref: "currency" },
    cha_name: String,
    cfs: String,
    vessel_egm_no: String,
    vessel_rotation_no: String,
    movement_date: Date,
    verified_date: Date,
    received_from_liner: Date,
    send_to_shipper: Date,
    custom_token: String,
    exam_mark: { type: String, enum: ["Y", "N"] },
    dbk_amount: Number,
    examine_date: Date,
    scroll_no: String,
    scroll_date: Date,
    assessment_complete_date: Date,
    form_13_id: String,
    form_13_apply_date: Date,
    form_13_received_date: Date,
    sli_submission_date: Date,
    is_are_status: { type: Boolean, default: false },
    is_fcr: { type: Boolean, default: false },
    stage: String,
}, {
    timestamps: true,
});
exports.default = (0, mongoose_1.model)("export_shipping_bill", exportShippingBillSchema);
