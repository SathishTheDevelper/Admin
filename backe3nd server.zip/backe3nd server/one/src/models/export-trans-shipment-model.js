"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const exportTransShipmentSchema = new mongoose_1.Schema({
    export_booking_id: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: "export_booking",
        required: true,
    },
    from: { type: mongoose_1.Schema.Types.ObjectId, ref: "seaport" },
    to: { type: mongoose_1.Schema.Types.ObjectId, ref: "seaport" },
    vessel_name: { type: mongoose_1.Schema.Types.ObjectId, ref: "vessel" },
    voyage_no: String,
    etd: Date,
    atd: Date,
    eta: Date,
    ata: Date,
    associate_email_sent: Date,
    associate_response: Date,
    shipper_email_sent: Date,
    stage: String,
}, {
    timestamps: true,
});
exports.default = (0, mongoose_1.model)("export_trans_shipment", exportTransShipmentSchema);
