"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const exportTransportSchema = new mongoose_1.Schema({
    export_booking_id: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: "export_booking",
        required: true,
    },
    trip_details: {
        vehicle_ownership: String,
        driver: String,
        diver_name: String,
        sub_contractor: String,
        driver_mobile_no: String,
        vehicle_no: String,
        trip_type: String,
        trip_start: Date,
        trip_end: Date,
        load_point: String,
        unload_point: String,
        trip_duration: Number,
        start_reading: Number,
        end_reading: Number,
        trip_distance: Number,
        with_loading: Number,
        without_loading: Number,
        trip_form: String,
        trip_to: String,
    },
    insurance_details: {
        insurance: String,
        policy_number: String,
    },
    lr_details: {
        lr_no: String,
        lr_date: String,
        lr_ref_type: String,
        print_format: String,
    },
    other_details: {
        container_info: String,
        consignee: String,
        validity: Date,
        private_remark: String,
        actual_transporter_name: String,
        actual_transporter_pan: String,
        freight: Number,
        diesel: Number,
        cash: Number,
        balance: Number,
    },
    trip_account_summary: {
        paid_total: Number,
        total_exp: Number,
        outstanding_total: Number,
        salary_exp: Number,
        labour_exp: Number,
        cleaner_exp: Number,
        spares_exp: Number,
        fuel_exp: Number,
        lube_exp: Number,
        other_exp: Number,
    },
    payment: [
        {
            date: Date,
            amout: Number,
            description: String,
        },
    ],
    expenses: [
        {
            date: Date,
            charge_head: { type: mongoose_1.Schema.Types.ObjectId, ref: "expense_type" },
            amount: Number,
            bill_no: String,
            bill_date: Date,
            bill_from: String,
            description: String,
        },
    ],
    stage: String,
}, {
    timestamps: true,
});
exports.default = (0, mongoose_1.model)("export_transport", exportTransportSchema);
