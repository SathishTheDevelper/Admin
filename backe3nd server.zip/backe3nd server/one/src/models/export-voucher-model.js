"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const exportVoucherSchema = new mongoose_1.Schema({
    export_booking_id: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: "export_booking",
        required: true,
    },
    agent: { type: String, enum: ['FFR', 'CHA'] },
    voucher_no: String,
    voucher_date: String,
    rate: Number,
    quantity: Number,
    amount: Number,
    payable_type: String,
    towards: { type: mongoose_1.Schema.Types.ObjectId, ref: 'expense_type' },
    remark: String,
    confidential_remark: String,
    stage: String,
});
exports.default = (0, mongoose_1.model)('export_voucher', exportVoucherSchema);
