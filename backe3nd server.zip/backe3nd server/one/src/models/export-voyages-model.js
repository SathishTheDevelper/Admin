"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const exportVoyageSchema = new mongoose_1.Schema({
    export_booking_id: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: "export_booking",
        required: true,
    },
    vessel_name: { type: mongoose_1.Schema.Types.ObjectId, ref: "vessel" },
    voyage_no: String,
    cut_of_date: Date,
    liner_bk_no: String,
    liner_bk_date: Date,
    coloader_no: String,
    coloader_bk_date: Date,
    agent_approved_date: Date,
});
exports.default = (0, mongoose_1.model)("export_voyages", exportVoyageSchema);
