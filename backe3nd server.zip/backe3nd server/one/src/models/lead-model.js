"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const addressSchema = new mongoose_1.Schema({
    address_line1: { type: String, required: true },
    address_line2: String,
    country: { type: mongoose_1.Schema.Types.ObjectId, ref: "country", required: true },
    state: { type: mongoose_1.Schema.Types.ObjectId, ref: "state", required: true },
    district: { type: mongoose_1.Schema.Types.ObjectId, ref: "district", required: true },
    area: { type: mongoose_1.Schema.Types.ObjectId, ref: "area", required: true },
    pincode: { type: Number, length: 6, required: true },
    latitude: { type: String },
    longitude: { type: String },
    type: {
        type: String,
        enum: ["Primary", "Communication", "Billing", "Factory"],
        required: true,
    },
});
const leadSchema = new mongoose_1.Schema({
    title: { type: mongoose_1.Schema.Types.ObjectId, ref: 'title' },
    name: { type: String, required: true },
    job_title: { type: mongoose_1.Schema.Types.ObjectId, ref: 'job_title' },
    department: { type: mongoose_1.Schema.Types.ObjectId, ref: 'department' },
    office_phone: { type: Number, required: true },
    mobile: { type: Number, required: true },
    fax: { type: Number },
    website: String,
    address: [addressSchema],
    email: [String],
    description: String,
    lead_status: { type: mongoose_1.Schema.Types.ObjectId, ref: 'lead_status' },
    status_description: String,
    lead_source: { type: mongoose_1.Schema.Types.ObjectId, ref: 'lead_source' },
    lead_description: String,
    lead_referred_by: String,
    campaign: String,
    done_by: { type: mongoose_1.Schema.Types.ObjectId, ref: 'user' },
}, {
    timestamps: true,
});
exports.default = (0, mongoose_1.model)("lead", leadSchema);
