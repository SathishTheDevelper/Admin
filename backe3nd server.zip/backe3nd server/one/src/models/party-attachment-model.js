"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const partyAttachmentSchema = new mongoose_1.Schema({
    party_kyc_id: { type: mongoose_1.Schema.Types.ObjectId, ref: 'party_kyc' },
    party_id: { type: mongoose_1.Schema.Types.ObjectId, ref: 'party' },
    files: { type: String, required: true },
}, {
    timestamps: true,
});
exports.default = (0, mongoose_1.model)("party_attachment", partyAttachmentSchema);
