"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const addressSchema = new mongoose_1.Schema({
    address_line1: { type: String, required: true },
    address_line2: String,
    country: { type: mongoose_1.Schema.Types.ObjectId, ref: "country", required: true },
    state: { type: mongoose_1.Schema.Types.ObjectId, ref: "state", required: true },
    district: { type: mongoose_1.Schema.Types.ObjectId, ref: "district", required: true },
    area: { type: mongoose_1.Schema.Types.ObjectId, ref: "area", required: true },
    pincode: { type: Number, length: 6, required: true },
    latitude: { type: String },
    longitude: { type: String },
    type: {
        type: String,
        enum: ["Billing", "Shipping", "Communication"],
        required: true,
    },
});
const contactDetailSchema = new mongoose_1.Schema({
    name: String,
    department: String,
    designation: String,
    whatsapp_no: String,
    mobile_no: [String],
    email: String,
});
const financialDetailSchema = new mongoose_1.Schema({
    credit_limit: Number,
    credit_period: Number,
    credit_terms: [String],
});
const bankDetailSchema = new mongoose_1.Schema({
    account_holder_name: { type: String, required: true, trim: true },
    account_no: { type: String, required: true, trim: true },
    bank_name: { type: String, required: true, trim: true },
    branch: { type: String, required: true, trim: true },
    ifsc_no: { type: String, required: true, trim: true },
    is_primary: { type: Boolean, default: false },
    status: { type: Boolean, default: true },
});
const kycDetailSchema = new mongoose_1.Schema({
    title: { type: String, required: true, trim: true, uppercase: true },
    files: { type: String, required: true },
    date_time: { type: Date, default: Date.now },
});
const partySchema = new mongoose_1.Schema({
    code: { type: String, required: true, trim: true, unique: true, uppercase: true },
    name: { type: String, required: true, trim: true },
    type: { type: String, enum: ["Customer", "Vendor"], required: true },
    pan_no: { type: String, trim: true, uppercase: true, maxLength: 10 },
    gst_no: { type: String, trim: true, uppercase: true, maxLength: 15 },
    iec_no: String,
    ad_code_no: String,
    remarks: String,
    note: String,
    party_service: { type: mongoose_1.Schema.Types.ObjectId, ref: 'party_service' },
    party_source: { type: mongoose_1.Schema.Types.ObjectId, ref: 'party_source' },
    party_rating: { type: String, enum: ['Prefered', 'Regular', 'Defaulter'] },
    party_network: [{ type: mongoose_1.Schema.Types.ObjectId, ref: 'party_network' }],
    party_mode: [{ type: mongoose_1.Schema.Types.ObjectId, ref: 'party_mode' }],
    address: [addressSchema],
    contact_detail: [contactDetailSchema],
    financial_detail: financialDetailSchema,
    bank_detail: [bankDetailSchema],
    kyc_detail: [kycDetailSchema],
    mobile_no: [String],
    landline_no: [String],
    sms_no: [String],
    whatsapp_no: [String],
    skype_id: [String],
    email: [String],
    status: { type: Boolean, default: true },
    completed: { type: Boolean, default: false },
}, {
    timestamps: true,
});
exports.default = (0, mongoose_1.model)("party", partySchema);
