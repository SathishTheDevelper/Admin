"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const partyServiceSchema = new mongoose_1.Schema({
    name: { type: String, unique: true, uppercase: true, trim: true },
    status: { type: Boolean, default: true },
});
exports.default = (0, mongoose_1.model)("party_service", partyServiceSchema);
