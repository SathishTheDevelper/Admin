"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const quotationModelSchema = new mongoose_1.Schema({
    quotation_no: { type: Number, required: true },
    date: { type: Date, required: true },
    from: { type: mongoose_1.Schema.Types.ObjectId, ref: 'location' },
    to: { type: mongoose_1.Schema.Types.ObjectId, ref: 'location' },
    incoterms: { type: mongoose_1.Schema.Types.ObjectId, ref: 'incoterms' },
    service: String,
    commodity: String,
    company: { type: mongoose_1.Schema.Types.ObjectId, ref: 'party' },
    agent: { type: mongoose_1.Schema.Types.ObjectId, ref: 'party' },
    customer: { type: mongoose_1.Schema.Types.ObjectId, ref: 'party' },
    no_of_cbm: Number,
    net_weight: Number,
    shipment_detail: [
        {
            length: Number,
            width: Number,
            height: Number,
            weight: String,
            amount: Number,
        }
    ],
    done_by: { type: mongoose_1.Schema.Types.ObjectId, ref: 'user' }
}, {
    timestamps: true,
});
exports.default = (0, mongoose_1.model)('quotation', quotationModelSchema);
