"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
let stateSchema = new mongoose_1.Schema({
    name: { type: String, required: true, trim: true, uppercase: true },
    code: Number,
    country: { type: mongoose_1.Schema.Types.ObjectId, ref: "country" },
    description: String,
    latitude: String,
    longitude: String,
    status: { type: Boolean, default: true },
}, {
    timestamps: true,
});
exports.default = (0, mongoose_1.model)("state", stateSchema);
