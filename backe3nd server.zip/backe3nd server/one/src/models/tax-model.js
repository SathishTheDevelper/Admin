"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
let taxSchema = new mongoose_1.Schema({
    tax_name: {
        type: String,
        trim: true,
        uppercase: true,
        required: true,
        unique: true,
    },
    tax_percentage: { type: Number, required: true },
    description: String,
    status: { type: Boolean, default: true },
}, {
    timestamps: true,
});
exports.default = (0, mongoose_1.model)("tax", taxSchema);
