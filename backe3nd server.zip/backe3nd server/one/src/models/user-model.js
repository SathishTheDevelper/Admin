"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const userSchema = new mongoose_1.Schema({
    user_name: { type: String, required: true },
    profile_photo: { type: String },
    mobile_no: String,
    additional_mobile_no: [String],
    contact_person: {
        name: String,
        designation: String,
        mobile_no: [String]
    },
    email: String,
    role: { type: mongoose_1.Schema.Types.ObjectId, ref: 'role' },
    password: { type: String },
    address: {
        address_line1: String,
        address_line2: String,
        area: { type: mongoose_1.Schema.Types.ObjectId, ref: 'area' },
        state: { type: mongoose_1.Schema.Types.ObjectId, ref: 'state' },
        district: { type: mongoose_1.Schema.Types.ObjectId, ref: 'district' },
        country: { type: mongoose_1.Schema.Types.ObjectId, ref: 'country' },
        pincode: Number,
    },
    academic_detail: [
        {
            institute_name: String,
            board: String,
            mark: Number,
            grade: String,
        }
    ],
    experience: [
        {
            organisation_name: String,
            address: {
                address_line1: String,
                address_line2: String,
                area: { type: mongoose_1.Schema.Types.ObjectId, ref: 'area' },
                state: { type: mongoose_1.Schema.Types.ObjectId, ref: 'state' },
                district: { type: mongoose_1.Schema.Types.ObjectId, ref: 'district' },
                country: { type: mongoose_1.Schema.Types.ObjectId, ref: 'country' },
                pincode: Number,
            },
            joined_date: Date,
            relieving: Date,
            designation: String,
        }
    ],
    status: { type: Boolean, default: true },
}, {
    timestamps: true,
});
exports.default = (0, mongoose_1.model)('user', userSchema);
