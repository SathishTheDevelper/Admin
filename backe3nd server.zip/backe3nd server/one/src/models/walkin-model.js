"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const walkinSchema = new mongoose_1.Schema({
    name: { type: String, required: true, trim: true, uppercase: true },
    pan_no: { type: String, trim: true, uppercase: true, maxLength: 10 },
    gst_no: { type: String, trim: true, uppercase: true, maxLength: 15 },
    mobile_no: [String],
    landline_no: [String],
    sms_no: [String],
    whatsapp_no: [String],
    skype_id: [String],
    email: [String],
    contact_detail: [
        {
            name: String,
            department: String,
            designation: String,
            whatsapp_no: String,
            mobile_no: [String],
            email: String,
        },
    ],
    status: { type: Boolean, default: true },
}, {
    timestamps: true,
});
exports.default = (0, mongoose_1.model)("walkin", walkinSchema);
