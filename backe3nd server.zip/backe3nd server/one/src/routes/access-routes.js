"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const access_menu_controller_1 = __importDefault(require("../controllers/access-menu-controller"));
const access_module_controller_1 = __importDefault(require("../controllers/access-module-controller"));
const access_option_controller_1 = __importDefault(require("../controllers/access-option-controller"));
const AccessRoutes = (0, express_1.Router)();
AccessRoutes.use('/option', access_option_controller_1.default)
    .use('/module', access_module_controller_1.default)
    .use('/menu', access_menu_controller_1.default)
    .get('/', (req, res, next) => {
    res.send("Access");
});
exports.default = AccessRoutes;
