"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const login_controller_1 = __importDefault(require("../controllers/login-controller"));
const menu_controller_1 = __importDefault(require("../controllers/menu-controller"));
const access_routes_1 = __importDefault(require("./access-routes"));
const master_1 = __importDefault(require("./master"));
const process_1 = __importDefault(require("./process"));
const app = (0, express_1.Router)();
app
    .use("/access", access_routes_1.default)
    .use("/master", master_1.default)
    .use("/process", process_1.default)
    .use('/login', login_controller_1.default)
    .use('/menu', menu_controller_1.default)
    .get("/", (req, res, next) => {
    res.send("Test app");
});
exports.default = app;
