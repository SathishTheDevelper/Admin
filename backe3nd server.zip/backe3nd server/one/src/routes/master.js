"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const airline_location_controller_1 = __importDefault(require("../controllers/airline-location-controller"));
const area_controller_1 = __importDefault(require("../controllers/area-controller"));
const attachment_type_controller_1 = __importDefault(require("../controllers/attachment-type-controller"));
const bank_controller_1 = __importDefault(require("../controllers/bank-controller"));
const buying_bill_controller_1 = __importDefault(require("../controllers/buying-bill-controller"));
const cargo_type_controller_1 = __importDefault(require("../controllers/cargo-type-controller"));
const charge_type_controller_1 = __importDefault(require("../controllers/charge-type-controller"));
const container_controller_1 = __importDefault(require("../controllers/container-controller"));
const country_controller_1 = __importDefault(require("../controllers/country-controller"));
const currency_controller_1 = __importDefault(require("../controllers/currency-controller"));
const district_controller_1 = __importDefault(require("../controllers/district-controller"));
const expense_type_controller_1 = __importDefault(require("../controllers/expense-type-controller"));
const fileupload_controller_1 = __importDefault(require("../controllers/fileupload-controller"));
const incoterms_controller_1 = __importDefault(require("../controllers/incoterms-controller"));
const location_controller_1 = __importDefault(require("../controllers/location-controller"));
const nature_of_contract_controller_1 = __importDefault(require("../controllers/nature-of-contract-controller"));
const package_type_controller_1 = __importDefault(require("../controllers/package-type-controller"));
const party_attachment_controller_1 = __importDefault(require("../controllers/party-attachment-controller"));
const party_controller_1 = __importDefault(require("../controllers/party-controller"));
const party_kyc_controller_1 = __importDefault(require("../controllers/party-kyc-controller"));
const party_mode_controller_1 = __importDefault(require("../controllers/party-mode-controller"));
const party_network_controller_1 = __importDefault(require("../controllers/party-network-controller"));
const party_service_controller_1 = __importDefault(require("../controllers/party-service-controller"));
const party_source_controller_1 = __importDefault(require("../controllers/party-source-controller"));
const plot_controller_1 = __importDefault(require("../controllers/plot-controller"));
const role_controller_1 = __importDefault(require("../controllers/role-controller"));
const seaport_controller_1 = __importDefault(require("../controllers/seaport-controller"));
const service_controller_1 = __importDefault(require("../controllers/service-controller"));
const state_controller_1 = __importDefault(require("../controllers/state-controller"));
const tax_controller_1 = __importDefault(require("../controllers/tax-controller"));
const terminal_controller_1 = __importDefault(require("../controllers/terminal-controller"));
const unit_controller_1 = __importDefault(require("../controllers/unit-controller"));
const user_controller_1 = __importDefault(require("../controllers/user-controller"));
const vessel_controller_1 = __importDefault(require("../controllers/vessel-controller"));
const MasterRoutes = (0, express_1.Router)();
MasterRoutes.use("/country", country_controller_1.default)
    .use("/state", state_controller_1.default)
    .use("/district", district_controller_1.default)
    .use("/service", service_controller_1.default)
    .use("/tax", tax_controller_1.default)
    .use("/terminal", terminal_controller_1.default)
    .use("/user", user_controller_1.default)
    .use("/vessel", vessel_controller_1.default)
    .use("/seaport", seaport_controller_1.default)
    .use("/role", role_controller_1.default)
    .use("/plot", plot_controller_1.default)
    .use("/bank", bank_controller_1.default)
    .use("/location", location_controller_1.default)
    .use("/area", area_controller_1.default)
    .use("/airline-location", airline_location_controller_1.default)
    .use("/cargo-type", cargo_type_controller_1.default)
    .use("/charge-type", charge_type_controller_1.default)
    .use("/container", container_controller_1.default)
    .use("/currency", currency_controller_1.default)
    .use("/nature-of-contract", nature_of_contract_controller_1.default)
    .use("/package-type", package_type_controller_1.default)
    .use("/party", party_controller_1.default)
    .use("/party-attachment", party_attachment_controller_1.default)
    .use("/party-kyc", party_kyc_controller_1.default)
    .use("/party-mode", party_mode_controller_1.default)
    .use("/party-network", party_network_controller_1.default)
    .use("/party-service", party_service_controller_1.default)
    .use("/party-source", party_source_controller_1.default)
    .use("/buying-bill", buying_bill_controller_1.default)
    .use("/expense-type", expense_type_controller_1.default)
    .use("/unit", unit_controller_1.default)
    .use("/incoterms", incoterms_controller_1.default)
    .use("/attachment-type", attachment_type_controller_1.default)
    .use("/file", fileupload_controller_1.default)
    .get("/", (req, res, next) => {
    res.send("Master");
});
exports.default = MasterRoutes;
