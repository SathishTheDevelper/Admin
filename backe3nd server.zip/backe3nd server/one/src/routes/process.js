"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const export_attachment_controller_1 = __importDefault(require("../controllers/export-attachment-controller"));
const export_awb_controller_1 = __importDefault(require("../controllers/export-awb-controller"));
const export_bl_controller_1 = __importDefault(require("../controllers/export-bl-controller"));
const export_booking_controller_1 = __importDefault(require("../controllers/export-booking-controller"));
const export_buying_controller_1 = __importDefault(require("../controllers/export-buying-controller"));
const export_container_controller_1 = __importDefault(require("../controllers/export-container-controller"));
const export_email_controller_1 = __importDefault(require("../controllers/export-email-controller"));
const export_flight_controller_1 = __importDefault(require("../controllers/export-flight-controller"));
const export_invoice_controller_1 = __importDefault(require("../controllers/export-invoice-controller"));
const export_parties_controller_1 = __importDefault(require("../controllers/export-parties-controller"));
const export_selling_controller_1 = __importDefault(require("../controllers/export-selling-controller"));
const export_shipping_bill_controller_1 = __importDefault(require("../controllers/export-shipping-bill-controller"));
const export_trans_shipment_controller_1 = __importDefault(require("../controllers/export-trans-shipment-controller"));
const export_transport_controller_1 = __importDefault(require("../controllers/export-transport-controller"));
const export_voucher_controller_1 = __importDefault(require("../controllers/export-voucher-controller"));
const export_voyage_controller_1 = __importDefault(require("../controllers/export-voyage-controller"));
const fileattachment_controller_1 = __importDefault(require("../controllers/fileattachment-controller"));
const quotation_controller_1 = __importDefault(require("../controllers/quotation-controller"));
const ProcessRoutes = (0, express_1.Router)();
ProcessRoutes.use("/export-booking", export_booking_controller_1.default)
    .use("/export-buying", export_buying_controller_1.default)
    .use("/export-container", export_container_controller_1.default)
    .use("/export-invoice", export_invoice_controller_1.default)
    .use("/export-selling", export_selling_controller_1.default)
    .use("/export-shipping-bill", export_shipping_bill_controller_1.default)
    .use("/export-transport", export_transport_controller_1.default)
    .use("/export-trans-shipment", export_trans_shipment_controller_1.default)
    .use("/export-parties", export_parties_controller_1.default)
    .use("/export-voucher", export_voucher_controller_1.default)
    .use("/export-filght", export_flight_controller_1.default)
    .use("/export-voyage", export_voyage_controller_1.default)
    .use("/export-attachment", export_attachment_controller_1.default)
    .use("/export-email", export_email_controller_1.default)
    .use("/quotation", quotation_controller_1.default)
    .use("/export-awb", export_awb_controller_1.default)
    .use("/export-bl", export_bl_controller_1.default)
    .use("/export-parties", export_parties_controller_1.default)
    .use("/fileattachment", fileattachment_controller_1.default)
    .get("/", (req, res, next) => {
    res.send("Process");
});
exports.default = ProcessRoutes;
