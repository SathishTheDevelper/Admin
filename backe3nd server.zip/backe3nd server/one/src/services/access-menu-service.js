"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const access_menu_model_1 = __importDefault(require("../models/access-menu-model"));
const crud_service_1 = require("./crud-service");
class AccessMenuService extends crud_service_1.CRUD {
    constructor() {
        super();
        this.model = access_menu_model_1.default;
        this.validateAdd = (data) => __awaiter(this, void 0, void 0, function* () {
            try {
                let check = yield this.retrieve({
                    menu_name: {
                        $regex: new RegExp("^" + data.menu_name.toLowerCase() + "$", "i"),
                    },
                });
                if (check)
                    return { success: false, message: "Already Exists" };
                return { success: true };
            }
            catch (error) {
                throw new Error(error);
            }
        });
        this.validateEdit = (data, id) => __awaiter(this, void 0, void 0, function* () {
            try {
                let check = yield this.retrieve({
                    menu_name: {
                        $regex: new RegExp("^" + data.menu_name.toLowerCase() + "$", "i"),
                    },
                    _id: { $ne: id },
                });
                if (check)
                    return { success: false, message: "Already Exists" };
                return { success: true };
            }
            catch (error) {
                throw new Error(error);
            }
        });
        this.validateDelete = (data) => __awaiter(this, void 0, void 0, function* () {
            try {
                return { success: true };
            }
            catch (error) {
                throw new Error(error);
            }
        });
        this.init();
    }
    init() {
        return __awaiter(this, void 0, void 0, function* () {
            if ((yield this.model.count()) == 0) {
                yield this.model.insertMany([
                    {
                        _id: "617248f0e0bd26a7970428a8",
                        menu_name: "Country",
                        route: "country",
                        module: "617021a6dbf1c7992e0da08c",
                        options: [
                            "61724814e0bd26a797042886",
                            "61724827e0bd26a79704288d",
                            "61724831e0bd26a797042891",
                            "61724848e0bd26a797042896",
                        ],
                        order_no: 1,
                        status: true,
                        createdAt: "2021-10-22T05:15:28.230Z",
                        updatedAt: "2021-10-22T05:43:49.777Z",
                        __v: 0,
                    },
                    {
                        _id: "6172490ee0bd26a7970428b0",
                        menu_name: "State",
                        route: "state",
                        module: "617021a6dbf1c7992e0da08c",
                        options: [
                            "61724814e0bd26a797042886",
                            "61724827e0bd26a79704288d",
                            "61724831e0bd26a797042891",
                            "61724848e0bd26a797042896",
                        ],
                        order_no: 2,
                        status: true,
                        createdAt: "2021-10-22T05:15:58.018Z",
                        updatedAt: "2021-10-22T05:43:57.805Z",
                        __v: 0,
                    },
                    {
                        _id: "61724db0e0bd26a79704298b",
                        menu_name: "District",
                        route: "district",
                        module: "617021a6dbf1c7992e0da08c",
                        options: [
                            "61724814e0bd26a797042886",
                            "61724827e0bd26a79704288d",
                            "61724831e0bd26a797042891",
                            "61724848e0bd26a797042896",
                        ],
                        order_no: 3,
                        status: true,
                        createdAt: "2021-10-22T05:35:44.643Z",
                        updatedAt: "2021-10-22T05:44:04.225Z",
                        __v: 0,
                    },
                    {
                        _id: "61724e0de0bd26a79704299e",
                        menu_name: "Area",
                        route: "area",
                        module: "617021a6dbf1c7992e0da08c",
                        options: [
                            "61724814e0bd26a797042886",
                            "61724827e0bd26a79704288d",
                            "61724831e0bd26a797042891",
                            "61724848e0bd26a797042896",
                        ],
                        order_no: 4,
                        status: true,
                        createdAt: "2021-10-22T05:37:17.906Z",
                        updatedAt: "2021-10-22T05:44:12.812Z",
                        __v: 0,
                    },
                    {
                        _id: "61724e59e0bd26a7970429a6",
                        menu_name: "Location",
                        route: "location",
                        module: "617021a6dbf1c7992e0da08c",
                        options: [
                            "61724814e0bd26a797042886",
                            "61724827e0bd26a79704288d",
                            "61724831e0bd26a797042891",
                            "61724848e0bd26a797042896",
                        ],
                        order_no: 5,
                        status: true,
                        createdAt: "2021-10-22T05:38:33.999Z",
                        updatedAt: "2021-10-22T05:44:21.115Z",
                        __v: 0,
                    },
                    {
                        _id: "6172510fa558f8878726b14f",
                        menu_name: "Airline Location",
                        route: "airline-location",
                        module: "617021a6dbf1c7992e0da08c",
                        options: [
                            "61724814e0bd26a797042886",
                            "61724827e0bd26a79704288d",
                            "61724831e0bd26a797042891",
                            "61724848e0bd26a797042896",
                        ],
                        order_no: 6,
                        status: true,
                        createdAt: "2021-10-22T05:50:07.641Z",
                        updatedAt: "2021-10-22T05:50:52.081Z",
                        __v: 0,
                    },
                    {
                        _id: "6172517fa558f8878726b161",
                        menu_name: "Attachement Type",
                        route: "attachement-type",
                        module: "617021a6dbf1c7992e0da08c",
                        options: [
                            "61724814e0bd26a797042886",
                            "61724827e0bd26a79704288d",
                            "61724831e0bd26a797042891",
                            "61724848e0bd26a797042896",
                        ],
                        order_no: 7,
                        status: true,
                        createdAt: "2021-10-22T05:51:59.973Z",
                        updatedAt: "2021-10-22T05:51:59.973Z",
                        __v: 0,
                    },
                    {
                        _id: "617251aba558f8878726b168",
                        menu_name: "Bank",
                        route: "bank",
                        module: "617021a6dbf1c7992e0da08c",
                        options: [
                            "61724814e0bd26a797042886",
                            "61724827e0bd26a79704288d",
                            "61724831e0bd26a797042891",
                            "61724848e0bd26a797042896",
                        ],
                        order_no: 8,
                        status: true,
                        createdAt: "2021-10-22T05:52:43.828Z",
                        updatedAt: "2021-10-22T05:52:43.828Z",
                        __v: 0,
                    },
                    {
                        _id: "617251dca558f8878726b16f",
                        menu_name: "Buying Bill",
                        route: "buying-bill",
                        module: "617021a6dbf1c7992e0da08c",
                        options: [
                            "61724814e0bd26a797042886",
                            "61724827e0bd26a79704288d",
                            "61724831e0bd26a797042891",
                            "61724848e0bd26a797042896",
                        ],
                        order_no: 9,
                        status: true,
                        createdAt: "2021-10-22T05:53:32.333Z",
                        updatedAt: "2021-10-22T05:53:32.333Z",
                        __v: 0,
                    },
                    {
                        _id: "6172520ea558f8878726b176",
                        menu_name: "Cargo Type",
                        route: "cargo-type",
                        module: "617021a6dbf1c7992e0da08c",
                        options: [
                            "61724814e0bd26a797042886",
                            "61724827e0bd26a79704288d",
                            "61724831e0bd26a797042891",
                            "61724848e0bd26a797042896",
                        ],
                        order_no: 10,
                        status: true,
                        createdAt: "2021-10-22T05:54:22.239Z",
                        updatedAt: "2021-10-22T05:54:22.239Z",
                        __v: 0,
                    },
                    {
                        _id: "61725235a558f8878726b180",
                        menu_name: "Charge Type",
                        route: "charge-type",
                        module: "617021a6dbf1c7992e0da08c",
                        options: [
                            "61724814e0bd26a797042886",
                            "61724827e0bd26a79704288d",
                            "61724831e0bd26a797042891",
                            "61724848e0bd26a797042896",
                        ],
                        order_no: 11,
                        status: true,
                        createdAt: "2021-10-22T05:55:01.940Z",
                        updatedAt: "2021-10-22T05:55:01.940Z",
                        __v: 0,
                    },
                    {
                        _id: "6172530ea558f8878726b1cf",
                        menu_name: "Expense Type",
                        route: "expense-type",
                        module: "617021a6dbf1c7992e0da08c",
                        options: [
                            "61724814e0bd26a797042886",
                            "61724827e0bd26a79704288d",
                            "61724831e0bd26a797042891",
                            "61724848e0bd26a797042896",
                        ],
                        order_no: 12,
                        status: true,
                        createdAt: "2021-10-22T05:58:38.102Z",
                        updatedAt: "2021-10-22T05:58:38.102Z",
                        __v: 0,
                    },
                    {
                        _id: "6172533fa558f8878726b1d6",
                        menu_name: "Package Type",
                        route: "package-type",
                        module: "617021a6dbf1c7992e0da08c",
                        options: [
                            "61724814e0bd26a797042886",
                            "61724827e0bd26a79704288d",
                            "61724831e0bd26a797042891",
                            "61724848e0bd26a797042896",
                        ],
                        order_no: 13,
                        status: true,
                        createdAt: "2021-10-22T05:59:27.604Z",
                        updatedAt: "2021-10-22T05:59:27.604Z",
                        __v: 0,
                    },
                    {
                        _id: "61725376a558f8878726b1e5",
                        menu_name: "Party",
                        route: "party",
                        module: "617021a6dbf1c7992e0da08c",
                        options: [
                            "61724814e0bd26a797042886",
                            "61724827e0bd26a79704288d",
                            "61724831e0bd26a797042891",
                            "61724848e0bd26a797042896",
                        ],
                        order_no: 14,
                        status: true,
                        createdAt: "2021-10-22T06:00:22.769Z",
                        updatedAt: "2021-10-22T06:00:22.769Z",
                        __v: 0,
                    },
                    {
                        _id: "617253aea558f8878726b1ed",
                        menu_name: "Party Kyc",
                        route: "party-kyc",
                        module: "617021a6dbf1c7992e0da08c",
                        options: [
                            "61724814e0bd26a797042886",
                            "61724827e0bd26a79704288d",
                            "61724831e0bd26a797042891",
                            "61724848e0bd26a797042896",
                        ],
                        order_no: 15,
                        status: true,
                        createdAt: "2021-10-22T06:01:18.128Z",
                        updatedAt: "2021-10-22T06:01:35.986Z",
                        __v: 0,
                    },
                    {
                        _id: "617253eaa558f8878726b1fe",
                        menu_name: "Party Mode",
                        route: "party-mode",
                        module: "617021a6dbf1c7992e0da08c",
                        options: [
                            "61724814e0bd26a797042886",
                            "61724827e0bd26a79704288d",
                            "61724831e0bd26a797042891",
                            "61724848e0bd26a797042896",
                        ],
                        order_no: 16,
                        status: true,
                        createdAt: "2021-10-22T06:02:18.391Z",
                        updatedAt: "2021-10-22T06:02:18.391Z",
                        __v: 0,
                    },
                    {
                        _id: "61725412a558f8878726b205",
                        menu_name: "Party Network",
                        route: "party-network",
                        module: "617021a6dbf1c7992e0da08c",
                        options: [
                            "61724814e0bd26a797042886",
                            "61724827e0bd26a79704288d",
                            "61724831e0bd26a797042891",
                            "61724848e0bd26a797042896",
                        ],
                        order_no: 17,
                        status: true,
                        createdAt: "2021-10-22T06:02:58.711Z",
                        updatedAt: "2021-10-22T06:02:58.711Z",
                        __v: 0,
                    },
                    {
                        _id: "61725448a558f8878726b20c",
                        menu_name: "Party service",
                        route: "party-service",
                        module: "617021a6dbf1c7992e0da08c",
                        options: [
                            "61724814e0bd26a797042886",
                            "61724827e0bd26a79704288d",
                            "61724831e0bd26a797042891",
                            "61724848e0bd26a797042896",
                        ],
                        order_no: 18,
                        status: true,
                        createdAt: "2021-10-22T06:03:52.472Z",
                        updatedAt: "2021-10-22T06:04:04.146Z",
                        __v: 0,
                    },
                    {
                        _id: "61725480a558f8878726b21a",
                        menu_name: "Party Source",
                        route: "party-source",
                        module: "617021a6dbf1c7992e0da08c",
                        options: [
                            "61724814e0bd26a797042886",
                            "61724827e0bd26a79704288d",
                            "61724831e0bd26a797042891",
                            "61724848e0bd26a797042896",
                        ],
                        order_no: 19,
                        status: true,
                        createdAt: "2021-10-22T06:04:48.995Z",
                        updatedAt: "2021-10-22T06:04:48.995Z",
                        __v: 0,
                    },
                    {
                        _id: "61725566a558f8878726b22a",
                        menu_name: "Container",
                        route: "container",
                        module: "617021a6dbf1c7992e0da08c",
                        options: [
                            "61724814e0bd26a797042886",
                            "61724827e0bd26a79704288d",
                            "61724831e0bd26a797042891",
                            "61724848e0bd26a797042896",
                        ],
                        order_no: 20,
                        status: true,
                        createdAt: "2021-10-22T06:08:38.780Z",
                        updatedAt: "2021-10-22T06:08:38.780Z",
                        __v: 0,
                    },
                    {
                        _id: "61725598a558f8878726b231",
                        menu_name: "Currency",
                        route: "currency",
                        module: "617021a6dbf1c7992e0da08c",
                        options: [
                            "61724814e0bd26a797042886",
                            "61724827e0bd26a79704288d",
                            "61724831e0bd26a797042891",
                            "61724848e0bd26a797042896",
                        ],
                        order_no: 21,
                        status: true,
                        createdAt: "2021-10-22T06:09:28.480Z",
                        updatedAt: "2021-10-22T06:09:28.480Z",
                        __v: 0,
                    },
                    {
                        _id: "6172562ca558f8878726b239",
                        menu_name: "Nature Of Contract",
                        route: "nature-of-contract",
                        module: "617021a6dbf1c7992e0da08c",
                        options: [
                            "61724814e0bd26a797042886",
                            "61724827e0bd26a79704288d",
                            "61724831e0bd26a797042891",
                            "61724848e0bd26a797042896",
                        ],
                        order_no: 22,
                        status: true,
                        createdAt: "2021-10-22T06:11:56.534Z",
                        updatedAt: "2021-10-22T06:11:56.534Z",
                        __v: 0,
                    },
                    {
                        _id: "61725661a558f8878726b241",
                        menu_name: "Plot",
                        route: "plot",
                        module: "617021a6dbf1c7992e0da08c",
                        options: [
                            "61724814e0bd26a797042886",
                            "61724827e0bd26a79704288d",
                            "61724831e0bd26a797042891",
                            "61724848e0bd26a797042896",
                        ],
                        order_no: 23,
                        status: true,
                        createdAt: "2021-10-22T06:12:49.960Z",
                        updatedAt: "2021-10-22T06:12:49.960Z",
                        __v: 0,
                    },
                    {
                        _id: "61725683a558f8878726b248",
                        menu_name: "Role",
                        route: "role",
                        module: "617021a6dbf1c7992e0da08c",
                        options: [
                            "61724814e0bd26a797042886",
                            "61724827e0bd26a79704288d",
                            "61724831e0bd26a797042891",
                            "61724848e0bd26a797042896",
                        ],
                        order_no: 24,
                        status: true,
                        createdAt: "2021-10-22T06:13:23.129Z",
                        updatedAt: "2021-10-22T06:13:23.129Z",
                        __v: 0,
                    },
                    {
                        _id: "617256bca558f8878726b250",
                        menu_name: "Seaport",
                        route: "seaport",
                        module: "617021a6dbf1c7992e0da08c",
                        options: [
                            "61724814e0bd26a797042886",
                            "61724827e0bd26a79704288d",
                            "61724831e0bd26a797042891",
                            "61724848e0bd26a797042896",
                        ],
                        order_no: 25,
                        status: true,
                        createdAt: "2021-10-22T06:14:20.538Z",
                        updatedAt: "2021-10-22T06:14:20.538Z",
                        __v: 0,
                    },
                    {
                        _id: "617256f3a558f8878726b25a",
                        menu_name: "Service",
                        route: "service",
                        module: "617021a6dbf1c7992e0da08c",
                        options: [
                            "61724814e0bd26a797042886",
                            "61724827e0bd26a79704288d",
                            "61724831e0bd26a797042891",
                            "61724848e0bd26a797042896",
                        ],
                        order_no: 26,
                        status: true,
                        createdAt: "2021-10-22T06:15:15.789Z",
                        updatedAt: "2021-10-22T06:15:30.026Z",
                        __v: 0,
                    },
                    {
                        _id: "61725742a558f8878726b269",
                        menu_name: "Tax",
                        route: "tax",
                        module: "617021a6dbf1c7992e0da08c",
                        options: [
                            "61724814e0bd26a797042886",
                            "61724827e0bd26a79704288d",
                            "61724831e0bd26a797042891",
                            "61724848e0bd26a797042896",
                        ],
                        order_no: 27,
                        status: true,
                        createdAt: "2021-10-22T06:16:34.954Z",
                        updatedAt: "2021-10-22T06:17:12.605Z",
                        __v: 0,
                    },
                    {
                        _id: "61725787a558f8878726b280",
                        menu_name: "Terminal",
                        route: "terminal",
                        module: "617021a6dbf1c7992e0da08c",
                        options: [
                            "61724814e0bd26a797042886",
                            "61724827e0bd26a79704288d",
                            "61724831e0bd26a797042891",
                            "61724848e0bd26a797042896",
                        ],
                        order_no: 28,
                        status: true,
                        createdAt: "2021-10-22T06:17:43.870Z",
                        updatedAt: "2021-10-22T06:17:43.870Z",
                        __v: 0,
                    },
                    {
                        _id: "617257c1a558f8878726b299",
                        menu_name: "User",
                        route: "user",
                        module: "617021a6dbf1c7992e0da08c",
                        options: [
                            "61724814e0bd26a797042886",
                            "61724827e0bd26a79704288d",
                            "61724831e0bd26a797042891",
                            "61724848e0bd26a797042896",
                        ],
                        order_no: 29,
                        status: true,
                        createdAt: "2021-10-22T06:18:41.017Z",
                        updatedAt: "2021-10-22T06:18:41.017Z",
                        __v: 0,
                    },
                    {
                        _id: "61725877a558f8878726b2a5",
                        menu_name: "Vessel",
                        route: "vessel",
                        module: "617021a6dbf1c7992e0da08c",
                        options: [
                            "61724814e0bd26a797042886",
                            "61724827e0bd26a79704288d",
                            "61724831e0bd26a797042891",
                            "61724848e0bd26a797042896",
                        ],
                        order_no: 30,
                        status: true,
                        createdAt: "2021-10-22T06:21:43.354Z",
                        updatedAt: "2021-10-22T06:21:43.354Z",
                        __v: 0,
                    },
                    {
                        _id: "617259cfa558f8878726b2b6",
                        menu_name: "Unit",
                        route: "unit",
                        module: "617021a6dbf1c7992e0da08c",
                        options: [
                            "61724814e0bd26a797042886",
                            "61724827e0bd26a79704288d",
                            "61724831e0bd26a797042891",
                            "61724848e0bd26a797042896",
                        ],
                        order_no: 31,
                        status: true,
                        createdAt: "2021-10-22T06:27:27.699Z",
                        updatedAt: "2021-10-22T06:27:27.699Z",
                        __v: 0,
                    },
                    {
                        _id: "61725c06a558f8878726b349",
                        menu_name: "Access Module",
                        route: "access-module",
                        module: "61725bcaa558f8878726b341",
                        options: [
                            "61724814e0bd26a797042886",
                            "61724827e0bd26a79704288d",
                            "61724831e0bd26a797042891",
                            "61724848e0bd26a797042896",
                        ],
                        order_no: 32,
                        status: true,
                        createdAt: "2021-10-22T06:36:54.225Z",
                        updatedAt: "2021-10-22T06:36:54.225Z",
                        __v: 0,
                    },
                    {
                        _id: "61725c3da558f8878726b350",
                        menu_name: "Access Option",
                        route: "access-option",
                        module: "61725bcaa558f8878726b341",
                        options: [
                            "61724814e0bd26a797042886",
                            "61724827e0bd26a79704288d",
                            "61724831e0bd26a797042891",
                            "61724848e0bd26a797042896",
                        ],
                        order_no: 33,
                        status: true,
                        createdAt: "2021-10-22T06:37:49.488Z",
                        updatedAt: "2021-10-22T06:38:49.150Z",
                        __v: 0,
                    },
                    {
                        _id: "61725c6ba558f8878726b363",
                        menu_name: "Export Booking",
                        route: "export-booking",
                        module: "617021cfdbf1c7992e0da5c5",
                        options: [],
                        order_no: 34,
                        status: true,
                        createdAt: "2021-10-22T06:38:35.405Z",
                        updatedAt: "2021-10-22T07:08:05.811Z",
                        __v: 0,
                    },
                    {
                        _id: "61725cdfa558f8878726b39c",
                        menu_name: "Second Stage - Transport",
                        route: "export-transport",
                        module: "617021cfdbf1c7992e0da5c5",
                        options: [],
                        order_no: 35,
                        status: true,
                        createdAt: "2021-10-22T06:40:31.745Z",
                        updatedAt: "2021-10-22T07:08:17.462Z",
                        __v: 0,
                    },
                    {
                        _id: "61725efaa558f8878726b47f",
                        menu_name: "Thrid Stage - Shipping Bill",
                        route: "export-shipping",
                        module: "617021cfdbf1c7992e0da5c5",
                        options: [],
                        order_no: 36,
                        status: true,
                        createdAt: "2021-10-22T06:49:30.745Z",
                        updatedAt: "2021-10-22T07:08:28.318Z",
                        __v: 0,
                    },
                    {
                        _id: "61725f26a558f8878726b48c",
                        menu_name: "Fourth Stage - Container",
                        route: "export-container",
                        module: "617021cfdbf1c7992e0da5c5",
                        options: [],
                        order_no: 37,
                        status: true,
                        createdAt: "2021-10-22T06:50:14.995Z",
                        updatedAt: "2021-10-22T07:08:39.283Z",
                        __v: 0,
                    },
                    {
                        _id: "61725fb7a558f8878726b4be",
                        menu_name: "Fifth Stage - AWB/BL",
                        route: "export-awb",
                        module: "617021cfdbf1c7992e0da5c5",
                        options: [],
                        order_no: 38,
                        status: true,
                        createdAt: "2021-10-22T06:52:39.393Z",
                        updatedAt: "2021-10-22T07:08:56.285Z",
                        __v: 0,
                    },
                    {
                        _id: "61725fdfa558f8878726b4c5",
                        menu_name: "Sixth Stage - Shipement",
                        route: "exporttransshipment",
                        module: "617021cfdbf1c7992e0da5c5",
                        options: [],
                        order_no: 39,
                        status: true,
                        createdAt: "2021-10-22T06:53:19.399Z",
                        updatedAt: "2021-10-22T07:09:10.312Z",
                        __v: 0,
                    },
                    {
                        _id: "61726061a558f8878726b4fd",
                        menu_name: "Final Stage - Rate",
                        route: "rate",
                        module: "617021cfdbf1c7992e0da5c5",
                        options: [],
                        order_no: 40,
                        status: true,
                        createdAt: "2021-10-22T06:55:29.159Z",
                        updatedAt: "2021-10-22T07:10:56.523Z",
                        __v: 0,
                    },
                    {
                        _id: "617260a2a558f8878726b50a",
                        menu_name: "Consolidate View",
                        route: "export-consolidateview",
                        module: "617021cfdbf1c7992e0da5c5",
                        options: [],
                        order_no: 41,
                        status: true,
                        createdAt: "2021-10-22T06:56:34.483Z",
                        updatedAt: "2021-10-22T07:12:39.974Z",
                        __v: 0,
                    },
                ]);
            }
        });
    }
    menu(filter) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                let result = (yield this.model
                    .find(Object.assign(Object.assign({}, filter), { status: true }))
                    .populate("options"));
                return result;
            }
            catch (error) {
                throw new Error(error);
            }
        });
    }
}
exports.default = AccessMenuService;
