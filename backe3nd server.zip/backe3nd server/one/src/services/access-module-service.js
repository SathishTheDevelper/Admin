"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const access_module_model_1 = __importDefault(require("../models/access-module-model"));
const crud_service_1 = require("./crud-service");
class AccessModuleService extends crud_service_1.CRUD {
    constructor() {
        super();
        this.model = access_module_model_1.default;
        this.validateAdd = (data) => __awaiter(this, void 0, void 0, function* () {
            try {
                let check = yield this.retrieve({
                    module_name: {
                        $regex: new RegExp("^" + data.module_name.toLowerCase() + "$", "i"),
                    },
                });
                if (check)
                    return { success: false, message: "Already Exists" };
                return { success: true };
            }
            catch (error) {
                throw new Error(error);
            }
        });
        this.validateEdit = (data, id) => __awaiter(this, void 0, void 0, function* () {
            try {
                let check = yield this.retrieve({
                    module_name: {
                        $regex: new RegExp("^" + data.module_name.toLowerCase() + "$", "i"),
                    },
                    _id: { $ne: id },
                });
                if (check)
                    return { success: false, message: "Already Exists" };
                return { success: true };
            }
            catch (error) {
                throw new Error(error);
            }
        });
        this.validateDelete = (data) => __awaiter(this, void 0, void 0, function* () {
            try {
                return { success: true };
            }
            catch (error) {
                throw new Error(error);
            }
        });
        this.init();
    }
    init() {
        return __awaiter(this, void 0, void 0, function* () {
            if ((yield this.model.countDocuments()) == 0) {
                yield this.model.insertMany([
                    {
                        _id: "617021a6dbf1c7992e0da08c",
                        module_name: "Master",
                        icon: "",
                        parent: null,
                        order_no: 1,
                        route: "master",
                        status: true,
                        updatedAt: "2021-10-22T19:16:16.651Z",
                        createdAt: "2021-10-20T14:03:18.610Z",
                        __v: 0,
                    },
                    {
                        _id: "617021cfdbf1c7992e0da5c5",
                        module_name: "Process",
                        icon: "",
                        parent: null,
                        order_no: 2,
                        route: "process",
                        status: true,
                        updatedAt: "2021-10-22T19:16:27.398Z",
                        createdAt: "2021-10-20T14:03:59.074Z",
                        __v: 0,
                    },
                    {
                        _id: "617247b1e0bd26a79704286e",
                        module_name: "Accounts",
                        icon: null,
                        parent: null,
                        order_no: 3,
                        route: "accounts",
                        status: true,
                        updatedAt: "2021-10-22T19:16:37.646Z",
                        createdAt: "2021-10-22T05:10:09.736Z",
                        __v: 0,
                    },
                    {
                        _id: "61725bcaa558f8878726b341",
                        module_name: "Access",
                        icon: null,
                        parent: null,
                        order_no: 4,
                        route: "access",
                        status: true,
                        updatedAt: "2021-10-22T19:13:40.561Z",
                        createdAt: "2021-10-22T06:35:54.608Z",
                        __v: 0,
                    },
                ]);
         / }
        });
    }
    grouping(parent, data) {
        let res = data.filter((e) => String(e.parent) === String(parent));
        return res.map((e) => {
            let obj = e;
            let children = this.grouping(e._id, data);
            if (children.length > 0)
                obj.children = children;
            return obj;
        });
    }
    getModule() {
        return __awaiter(this, void 0, void 0, function* () {
            let moduleList = yield this.list({ status: true });
            let data = moduleList.map((e) => {
                let parent = e.parent;
                return {
                    _id: e._id,
                    menu_name: e.module_name,
                    parent: parent ? parent === null || parent === void 0 ? void 0 : parent._id : null,
                    icon: e.icon,
                };
            });
            return this.grouping(null, data);
        });
    }
}
exports.default = AccessModuleService;
