"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const access_option_model_1 = __importDefault(require("../models/access-option-model"));
const crud_service_1 = require("./crud-service");
class AccessOptionService extends crud_service_1.CRUD {
    constructor() {
        super();
        this.model = access_option_model_1.default;
        this.validateAdd = (data) => __awaiter(this, void 0, void 0, function* () {
            try {
                let check = yield this.retrieve({
                    option_name: {
                        $regex: new RegExp("^" + data.option_name.toLowerCase() + "$", "i"),
                    },
                });
                if (check)
                    return { success: false, message: "Already Exists" };
                return { success: true };
            }
            catch (error) {
                throw new Error(error);
            }
        });
        this.validateEdit = (data, id) => __awaiter(this, void 0, void 0, function* () {
            try {
                let check = yield this.retrieve({
                    option_name: {
                        $regex: new RegExp("^" + data.option_name.toLowerCase() + "$", "i"),
                    },
                    _id: { $ne: id },
                });
                if (check)
                    return { success: false, message: "Already Exists" };
                return { success: true };
            }
            catch (error) {
                throw new Error(error);
            }
        });
        this.validateDelete = (data) => __awaiter(this, void 0, void 0, function* () {
            try {
                return { success: true };
            }
            catch (error) {
                throw new Error(error);
            }
        });
        this.init();
    }
    init() {
        return __awaiter(this, void 0, void 0, function* () {
            if ((yield this.model.count()) == 0) {
                yield this.model.insertMany([
                    {
                        _id: "61724814e0bd26a797042886",
                        option_name: "Add",
                        order_no: 1,
                        status: true,
                        createdAt: "2021-10-22T05:11:48.787Z",
                        updatedAt: "2021-10-22T05:11:48.787Z",
                        __v: 0,
                    },
                    {
                        _id: "61724827e0bd26a79704288d",
                        option_name: "Edit",
                        order_no: 2,
                        status: true,
                        createdAt: "2021-10-22T05:12:07.198Z",
                        updatedAt: "2021-10-22T05:12:07.198Z",
                        __v: 0,
                    },
                    {
                        _id: "61724831e0bd26a797042891",
                        option_name: "List",
                        order_no: 3,
                        status: true,
                        createdAt: "2021-10-22T05:12:17.217Z",
                        updatedAt: "2021-10-22T05:12:17.217Z",
                        __v: 0,
                    },
                    {
                        _id: "61724848e0bd26a797042896",
                        option_name: "Delete",
                        order_no: 4,
                        status: true,
                        createdAt: "2021-10-22T05:12:40.839Z",
                        updatedAt: "2021-10-22T05:12:40.839Z",
                        __v: 0,
                    },
                    {
                        _id: "6172485ae0bd26a79704289a",
                        option_name: "View",
                        order_no: 5,
                        status: true,
                        createdAt: "2021-10-22T05:12:58.067Z",
                        updatedAt: "2021-10-22T05:12:58.067Z",
                        __v: 0,
                    },
                    {
                        _id: "61724872e0bd26a79704289f",
                        option_name: "PDF",
                        order_no: 6,
                        status: true,
                        createdAt: "2021-10-22T05:13:22.755Z",
                        updatedAt: "2021-10-22T05:13:22.755Z",
                        __v: 0,
                    },
                ]);
            }
        });
    }
}
exports.default = AccessOptionService;
