"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs_1 = require("fs");
const export_attachment_model_1 = __importDefault(require("../models/export-attachment-model"));
const crud_service_1 = require("./crud-service");
class ExportAttachmentService extends crud_service_1.CRUD {
    constructor() {
        super();
        this.model = export_attachment_model_1.default;
        this.validateAdd = (data) => __awaiter(this, void 0, void 0, function* () {
            try {
                return { success: true };
            }
            catch (error) {
                throw new Error(error);
            }
        });
        this.validateEdit = (data, id) => __awaiter(this, void 0, void 0, function* () {
            try {
                return { success: true };
            }
            catch (error) {
                throw new Error(error);
            }
        });
        this.validateDelete = (data) => __awaiter(this, void 0, void 0, function* () {
            try {
                return { success: true };
            }
            catch (error) {
                throw new Error(error);
            }
        });
    }
    updateById(data, id) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                if (this.validateEdit) {
                    let check = yield this.validateEdit(data, id);
                    if (check.success !== true)
                        throw new Error(check.message);
                }
                let old = yield this.retrieveById(id);
                if ((0, fs_1.existsSync)(old.file)) {
                    (0, fs_1.unlinkSync)(old.file);
                }
                yield this.model.updateOne({ _id: id }, data);
                let result = yield this.retrieveById(id);
                yield this.callBackEdit(result);
                return { success: true, data: result, message: "Successfully Updated" };
            }
            catch (error) {
                throw new Error(error);
            }
        });
    }
    callBackDelete(data) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                if ((0, fs_1.existsSync)(data.file)) {
                    (0, fs_1.unlinkSync)(data.file);
                }
            }
            catch (error) {
                throw new Error(error);
            }
        });
    }
}
exports.default = ExportAttachmentService;
