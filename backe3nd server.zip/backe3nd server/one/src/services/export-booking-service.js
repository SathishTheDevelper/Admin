"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const export_booking_model_1 = __importDefault(require("../models/export-booking-model"));
const crud_service_1 = require("./crud-service");
class ExportBookingService extends crud_service_1.CRUD {
    constructor() {
        super();
        this.model = export_booking_model_1.default;
        this.validateAdd = (data) => __awaiter(this, void 0, void 0, function* () {
            try {
                let check = yield this.retrieve({
                    b_no: data.b_no,
                    b_year: data.b_year,
                    b_month: data.b_month,
                });
                if (check)
                    return { success: false, message: "Already Exists" };
                return { success: true };
            }
            catch (error) {
                throw new Error(error);
            }
        });
        this.validateEdit = (data, id) => __awaiter(this, void 0, void 0, function* () {
            try {
                let check = yield this.retrieve({
                    b_no: data.b_no,
                    b_year: data.b_year,
                    b_month: data.b_month,
                    _id: { $ne: id },
                });
                if (check)
                    return { success: false, message: "Already Exists" };
                return { success: true };
            }
            catch (error) {
                throw new Error(error);
            }
        });
        this.validateDelete = (data) => __awaiter(this, void 0, void 0, function* () {
            try {
                return { success: true };
            }
            catch (error) {
                throw new Error(error);
            }
        });
    }
    bookingReference(date) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                let dtBooking = new Date(date);
                let arrMonth = [
                    "J",
                    "K",
                    "L",
                    "A",
                    "B",
                    "C",
                    "D",
                    "E",
                    "F",
                    "G",
                    "H",
                    "I",
                ];
                let arrABC = [
                    "A",
                    "B",
                    "C",
                    "D",
                    "E",
                    "F",
                    "G",
                    "H",
                    "I",
                    "J",
                    "K",
                    "L",
                    "M",
                    "N",
                    "O",
                    "P",
                    "Q",
                    "R",
                    "S",
                    "T",
                    "U",
                    "V",
                    "W",
                    "X",
                    "Y",
                    "Z",
                ];
                let bmonth = arrMonth[dtBooking.getMonth()];
                let byear = arrABC[(dtBooking.getFullYear() - 19) % 26];
                let getLatestNumber = yield this.model
                    .findOne({ b_year: byear, b_month: bmonth })
                    .sort({ b_no: -1 });
                let bno = 1;
                if (getLatestNumber)
                    bno += getLatestNumber.b_no;
                return { b_year: byear, b_month: bmonth, b_no: bno };
            }
            catch (error) {
                throw new Error(error);
            }
        });
    }
    list(filter = {}) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                let result = (yield this.model
                    .find(filter)
                    .populate("shipper")
                    .populate("consignee")
                    .populate("orgin_port")
                    .populate("loading_port")
                    .populate("discharge_port")
                    .populate("destination_port")
                    .populate("package_type")
                    .populate("cargo_type")
                    .populate("nature_of_contract")
                    .populate("service_provided")
                    .populate("incoterms"));
                return result;
            }
            catch (error) {
                throw new Error(error);
            }
        });
    }
    approve(id, stage, doneby) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                let result = yield this.model.findByIdAndUpdate(id, { stage: stage });
                return { success: true, data: result, message: "Successfully Approved" };
            }
            catch (error) {
                throw new Error(error);
            }
        });
    }
}
exports.default = ExportBookingService;
