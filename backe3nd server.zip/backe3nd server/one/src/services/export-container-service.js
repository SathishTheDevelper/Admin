"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const export_container_model_1 = __importDefault(require("../models/export-container-model"));
const crud_service_1 = require("./crud-service");
class ExportContainerService extends crud_service_1.CRUD {
    constructor() {
        super();
        this.model = export_container_model_1.default;
        this.validateAdd = (data) => __awaiter(this, void 0, void 0, function* () {
            try {
                return { success: true };
            }
            catch (error) {
                throw new Error(error);
            }
        });
        this.validateEdit = (data, id) => __awaiter(this, void 0, void 0, function* () {
            try {
                return { success: true };
            }
            catch (error) {
                throw new Error(error);
            }
        });
        this.validateDelete = (data) => __awaiter(this, void 0, void 0, function* () {
            try {
                return { success: true };
            }
            catch (error) {
                throw new Error(error);
            }
        });
    }
    list(filter = {}) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                let result = (yield this.model
                    .find(filter)
                    .populate("export_booking_id")
                    .populate("transport_planning.factory_cfs")
                    .populate("container_details.container")
                    .populate("container_details.invoice_no")
                    .populate("packages_and_weight_details.package_type")
                    .populate("plot_panel.plot")
                    .populate("factory_panel.factory")
                    .populate("cfs_panel.cfs")
                    .populate("cfs_panel.clearance_type")
                    .populate("port_panel.terminal"));
                return result;
            }
            catch (error) {
                throw new Error(error);
            }
        });
    }
}
exports.default = ExportContainerService;
