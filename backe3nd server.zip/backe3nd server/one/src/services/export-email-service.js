"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const export_email_model_1 = __importDefault(require("../models/export-email-model"));
const crud_service_1 = require("./crud-service");
class ExportEmailService extends crud_service_1.CRUD {
    constructor() {
        super();
        this.model = export_email_model_1.default;
        this.validateAdd = (data) => __awaiter(this, void 0, void 0, function* () {
            try {
                let check = yield this.retrieve({ export_booking_id: { $regex: new RegExp("^" + data.export_booking_id + "$", "i") } });
                if (check)
                    return { success: false, message: "Already Exists" };
                return { success: true };
            }
            catch (error) {
                throw new Error(error);
            }
        });
        this.validateEdit = (data, id) => __awaiter(this, void 0, void 0, function* () {
            try {
                let check = yield this.retrieve({ export_booking_id: { $regex: new RegExp("^" + data.export_booking_id + "$", "i") }, _id: { $ne: id } });
                if (check)
                    return { success: false, message: "Already Exists" };
                return { success: true };
            }
            catch (error) {
                throw new Error(error);
            }
        });
        this.validateDelete = (data) => __awaiter(this, void 0, void 0, function* () {
            try {
                return { success: true };
            }
            catch (error) {
                throw new Error(error);
            }
        });
    }
}
exports.default = ExportEmailService;
