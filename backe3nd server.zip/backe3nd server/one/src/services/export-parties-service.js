"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const export_parties_model_1 = __importDefault(require("../models/export-parties-model"));
const crud_service_1 = require("./crud-service");
class ExportPartiesService extends crud_service_1.CRUD {
    constructor() {
        super();
        this.model = export_parties_model_1.default;
        this.validateAdd = (data) => __awaiter(this, void 0, void 0, function* () {
            try {
                return { success: true };
            }
            catch (error) {
                throw new Error(error);
            }
        });
        this.validateEdit = (data, id) => __awaiter(this, void 0, void 0, function* () {
            try {
                return { success: true };
            }
            catch (error) {
                throw new Error(error);
            }
        });
        this.validateDelete = (data) => __awaiter(this, void 0, void 0, function* () {
            try {
                return { success: true };
            }
            catch (error) {
                throw new Error(error);
            }
        });
    }
    listparties(export_booking_id) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                let result = (yield this.model.find({
                    export_booking_id: export_booking_id,
                }));
                let parties = result.map((e) => {
                    return {
                        party_mode: e.party_mode,
                        party_id: e.party_id,
                    };
                });
                return { export_booking_id: export_booking_id, parties: parties };
            }
            catch (error) {
                throw new Error(error);
            }
        });
    }
    view(export_booking_id) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                let result = (yield this.model
                    .find({ export_booking_id: export_booking_id })
                    .populate("export_booking_id")
                    .populate("party_mode")
                    .populate("party_id"));
                return result;
            }
            catch (error) {
                throw new Error(error);
            }
        });
    }
    save(data) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                yield this.model.deleteMany({
                    export_booking_id: data.export_booking_id,
                });
                var addData = data.parties.map((o) => {
                    return {
                        export_booking_id: data.export_booking_id,
                        party_mode: o.party_mode,
                        party_id: o.party_id,
                    };
                });
                let result = yield this.model.insertMany(addData);
                return { success: true, data: result, message: "Successfully Saved" };
            }
            catch (error) {
                throw error;
            }
        });
    }
}
exports.default = ExportPartiesService;
