"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const access_menu_service_1 = __importDefault(require("./access-menu-service"));
const access_module_service_1 = __importDefault(require("./access-module-service"));
class MenuService {
    constructor() {
        this.moduleservice = new access_module_service_1.default();
        this.menuservice = new access_menu_service_1.default();
        this.init();
    }
    init() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                let menuList = yield this.menuservice.menu();
                let moduleList = yield this.moduleservice.list({
                    status: true,
                });
                let data1 = menuList.map((e) => ({
                    _id: e._id,
                    menu_name: e.menu_name,
                    parent: e.module,
                    options: e.options,
                    route: e.route,
                }));
                let data2 = moduleList.map((e) => ({
                    _id: e._id,
                    menu_name: e.module_name,
                    parent: e.parent,
                    icon: e.icon,
                }));
                this.data = [...data1, ...data2];
            }
            catch (error) {
                throw new Error(error);
            }
        });
    }
    grouping(parent, data) {
        let res = data.filter((e) => String(e.parent) === String(parent));
        return res.map((e) => {
            let obj = e;
            let children = this.grouping(e._id, data);
            if (children.length > 0)
                obj.children = children;
            return obj;
        });
    }
    getMenus(user_id) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                let menuList;
                // let userservice = new UserService();
                // let user = await userservice.retrieveById(user_id);
                // if (user.role?.toLowerCase() == "super admin") {          
                menuList = yield this.menuservice.model.find({ status: true }).populate('options').sort({ order_no: 1 });
                // } else {
                //   let assignedMenus = await this.accesssettingservice.menuList(user_id);
                //   menuList= assignedMenus?.map((e) => {
                //     let obj: any = e.menu_id;
                //     obj.options = e.options;
                //     return obj;
                //   });
                // }
                let moduleList = yield this.moduleservice.model.find({ status: true, }).sort({ order_no: 1 });
                let moduleListArray = [];
                menuList.forEach((e) => {
                    let parent = e.module;
                    do {
                        let gp = moduleList.find((el) => String(el._id) === String(parent));
                        if (!gp)
                            break;
                        let i = moduleListArray.findIndex((el) => String(el._id) === String(parent));
                        if (i === -1)
                            moduleListArray.push(gp);
                        if ((gp === null || gp === void 0 ? void 0 : gp.parent) != null) {
                            let m = gp.parent;
                            parent = m._id;
                        }
                        else
                            parent = null;
                    } while (parent && parent != null);
                });
                let data1 = menuList.map((e) => ({
                    _id: e._id,
                    menu_name: e.menu_name,
                    parent: e.module,
                    options: e.options,
                    route: e.route,
                }));
                let data2 = moduleListArray.map((e) => {
                    let parent = e.parent;
                    return {
                        _id: e._id,
                        menu_name: e.module_name,
                        parent: parent ? parent : null,
                        icon: e.icon,
                        route: e.route,
                    };
                });
                let data = [...data2, ...data1];
                return { menu: menuList, menu_tree: this.grouping(null, data) };
            }
            catch (error) {
                throw new Error(error);
            }
        });
    }
}
exports.default = MenuService;
