"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const quotation_model_1 = __importDefault(require("../models/quotation-model"));
const crud_service_1 = require("./crud-service");
class QuotationService extends crud_service_1.CRUD {
    constructor() {
        super();
        this.model = quotation_model_1.default;
        this.validateAdd = (data) => __awaiter(this, void 0, void 0, function* () {
            var _a;
            try {
                let check = yield this.retrieve({ service: { $regex: new RegExp("^" + ((_a = data.service) === null || _a === void 0 ? void 0 : _a.toLowerCase()) + "$", "i") } });
                if (check)
                    return { success: false, message: "Already Exists" };
                return { success: true };
            }
            catch (error) {
                throw new Error(error);
            }
        });
        this.validateEdit = (data, id) => __awaiter(this, void 0, void 0, function* () {
            var _b;
            try {
                let check = yield this.retrieve({ service: { $regex: new RegExp("^" + ((_b = data.service) === null || _b === void 0 ? void 0 : _b.toLowerCase()) + "$", "i") }, _id: { $ne: id } });
                if (check)
                    return { success: false, message: "Already Exists" };
                return { success: true };
            }
            catch (error) {
                throw new Error(error);
            }
        });
        this.validateDelete = (data) => __awaiter(this, void 0, void 0, function* () {
            try {
                return { success: true };
            }
            catch (error) {
                throw new Error(error);
            }
        });
    }
    quotationReference(date) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                let dtBooking = new Date(date);
                let arrMonth = [
                    "J",
                    "K",
                    "L",
                    "A",
                    "B",
                    "C",
                    "D",
                    "E",
                    "F",
                    "G",
                    "H",
                    "I",
                ];
                let arrABC = [
                    "A",
                    "B",
                    "C",
                    "D",
                    "E",
                    "F",
                    "G",
                    "H",
                    "I",
                    "J",
                    "K",
                    "L",
                    "M",
                    "N",
                    "O",
                    "P",
                    "Q",
                    "R",
                    "S",
                    "T",
                    "U",
                    "V",
                    "W",
                    "X",
                    "Y",
                    "Z",
                ];
                let bmonth = arrMonth[dtBooking.getMonth()];
                let byear = arrABC[(dtBooking.getFullYear() - 19) % 26];
                let getLatestNumber = yield this.model
                    .findOne({ b_year: byear, b_month: bmonth })
                    .sort({ b_no: -1 });
                let bno = 1;
                if (getLatestNumber)
                    bno += getLatestNumber.b_no;
                return { b_year: byear, b_month: bmonth, b_no: bno };
            }
            catch (error) {
                throw new Error(error);
            }
        });
    }
}
exports.default = QuotationService;
