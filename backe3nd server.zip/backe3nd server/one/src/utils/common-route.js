"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CommonRoutes = void 0;
// import {GridFsStorage} from 'multer-gridfs-storage';
// import multer from 'multer';
// const app = express();
// const storage = new GridFsStorage({url: 'mongodb://yourhost:27017/database'});
// import * as fs from 'fs';
// const upload = multer({ dest: 'uploads/' });
// app.post('/profile', upload.single('avatar'), function (req, res, next) {
//   const {file} = req;
//   const stream = fs.createReadStream(file.path);
//   storage.fromStream(stream, req, file)
//     .then(() => res.send('File uploaded'))
//     .catch(() => res.status(500).send('error'));
// });
class CommonRoutes {
    constructor(service) {
        this.service = service;
        this.list = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                let service = new this.service();
                res.json(yield service.list(req.query));
            }
            catch (error) {
                res.json({ success: false, message: error.message });
            }
        });
        this.retrieve = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                let service = new this.service();
                res.json(yield service.retrieveById(req.params.id));
            }
            catch (error) {
                res.json({ success: false, message: error.message });
            }
        });
        this.add = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                let service = new this.service();
                res.json(yield service.add(req.body));
            }
            catch (error) {
                res.json({ success: false, message: error.message });
            }
        });
        //   addFile = async (req: Request, res: Response) => {
        //     try {
        //       const { file } = req;
        //       const stream = fs.createReadStream(file.path);
        //       storage
        //         .fromStream(stream, req, file)
        //         .then(() => res.send("File uploaded"))
        //         .catch(() => res.status(500).send("error"));
        //     } catch (error: any) {
        //       res.json({ success: false, message: error.message });
        //     }
        //   };
        this.update = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                let service = new this.service();
                res.json(yield service.updateById(req.body, req.params.id));
            }
            catch (error) {
                res.json({ success: false, message: error.message });
            }
        });
        this.delete = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                let service = new this.service();
                res.json(yield service.deleteById(req.params.id));
            }
            catch (error) {
                res.json({ success: false, message: error.message });
            }
        });
    }
}
exports.CommonRoutes = CommonRoutes;
