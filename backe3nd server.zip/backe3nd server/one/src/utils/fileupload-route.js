"use strict";
// import dotenv from "dotenv";
// import { Request, Response, Router } from "express";
// import multer from "multer";
// import { GridFsStorage } from "multer-gridfs-storage";
// dotenv.config();
// const url = "mongodb://" + process.env.URL + process.env.DB;
// console.log(url);
// let storage = new GridFsStorage({
//   url: url,
//   file: (req, file) => {
//     return {
//       bucketName: "profile", //Setting collection name, default name is fs
//       filename: file.originalname, //Setting file name to original name of file
//     };
//   },
// });
// let upload: any = multer({ storage });
// const FileUploadRoute = {
// get= async (req: Request, res: Response) => {
//   try {
//   } catch (error) {}
// }
// postFile = asy(upload.array("file"), req: Request, res: Response) => {
//   const { file } = req;
//   res.send(req.files);
// }
// }
// //export default FileUploadRoute;
